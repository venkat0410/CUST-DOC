# Siemens Xpedition Layout 2510 – Step 1: PCB Reader & Information Extraction

**Project Location:** `E:\Creative\PCB\CUST-DOC\REV0.1`  
**Version:** `2510.1.0`  
**Target Platform:** Windows / Siemens Xpedition Layout 2510 (and Expedition PCB)

---

## 1. Executive Summary & Objective

This application is the **Step 1 Foundation** for the local **PCB Documentation & Print Automation tool for Siemens Xpedition Layout 2510**.

### Scope of Step 1
- **File Selection:** Allows user to select any Xpedition PCB design file (`.pcb`, `.job`, `.hkp`, `.kpcb`).
- **Automation & Reading:** Opens and reads the design using Siemens Xpedition Layout 2510 automation/COM interface (`MGCPCB.ExpeditionPCBApplication`), with native Direct ASCII/HKP parsing and simulation fallback.
- **Automatic Parameter Extraction:**
  - PCB Design Name and Full Path
  - Native Units (`mm`, `mil`, `inch`, `um`)
  - True Copper Layer Count and Names (excluding silkscreen, solder mask, assembly, documentation, user, mechanical, dielectric, and DXF layers)
  - Board Outline Detection (`Detected` / `Not Detected`)
  - Board Dimensions: `Width = Xmax - Xmin`, `Height = Ymax - Ymin`
  - Board Coordinate Ranges: `[Xmin → Xmax]`, `[Ymin → Ymax]`
  - Board Origin: `(Origin X, Origin Y)`
  - Orientation: `Landscape` (Width > Height), `Portrait` (Height > Width), `Square` (Width == Height)
- **Original PCB Protection:** Absolute read-only guarantee (`epcbDoNotSaveChanges = 0`). The design is never modified, rotated, saved, or altered.
- **Modular Architecture:** Cleanly isolates the UI from the extraction and automation engine, establishing the foundation for future stages (DXF import, PDF generation, title blocks, documentation views).

---

## 2. Siemens Xpedition Layout 2510 API Investigation Matrix

The table below documents the official automation interfaces and methods in Siemens Xpedition Layout 2510 (MGCPCB COM Automation & Type Library):

| Requirement | Official API / Method | Verified on Current Host? | Technical Implementation & Verification Notes |
| :--- | :--- | :---: | :--- |
| **1. Open PCB** | `app = CreateObject("MGCPCB.ExpeditionPCBApplication")`<br>`doc = app.OpenDocument(Path, ReadOnly=True)`<br>`doc.Validate(-1)` | **UNVERIFIED\*** | Opens the design database in read-only mode to guarantee original PCB protection. Verification requires live Xpedition Layout 2510 workstation. |
| **2. Read PCB metadata** | `doc.Name`<br>`doc.Path`<br>`doc.FullName` | **UNVERIFIED\*** | Extracts active design name and project path. Queried prior to document session closure. |
| **3. Read board outline** | `doc.BoardOutline.Geometry.Points`<br>`doc.BoardOutlines.Item(1).Geometry` | **UNVERIFIED\*** | Extracts actual polygon contour vertices (`Point.X`, `Point.Y`). Direct ASCII fallback parser verified. |
| **4. Read bounding box** | `doc.BoardOutline.GetBoundingBox(minX, minY, maxX, maxY)`<br>or `min(points.X), max(points.X)` | **UNVERIFIED\*** | Preserves true design coordinates (positive, negative, non-zero origin). Computes `Width = Xmax - Xmin`, `Height = Ymax - Ymin`. Bounding box engine verified. |
| **5. Read board origin** | `doc.SetupParameter.OriginX`<br>`doc.SetupParameter.OriginY`<br>`doc.ActiveCoordinateSystem` | **UNVERIFIED\*** | Captures design origin and user coordinate systems. Coordinate preservation engine verified. |
| **6. Read layers** | `doc.Layers`<br>`doc.Layers.Count`<br>`doc.Layers.Item(i)` | **UNVERIFIED\*** | Iterates the design layer collection. Reads `layer.Name`, `layer.Type`, and `layer.LayerClass`. |
| **7. Detect copper layers** | `layer.Type in [epcbLayerTypeSignal(1), epcbLayerTypePlane(2), epcbLayerTypeSplitPlane(3), epcbLayerTypeMixed(4)]`<br>or `layer.LayerClass == epcbLayerClassConductor(1)` | **UNVERIFIED\*** | Strictly filters out non-copper layers (`Silkscreen`, `SolderMask`, `PasteMask`, `Assembly`, `Documentation`, `User`, `Mechanical`, `DXF`, `Dielectric`). Layer classification filter verified. |
| **8. Read units** | `doc.SetupParameter.Units`<br>`doc.ActiveUnit` (`EPcbUnit`) | **UNVERIFIED\*** | Maps `EPcbUnit.MM (1)`, `EPcbUnit.MILS (2)`, `EPcbUnit.INCH (3)`, `EPcbUnit.MICRON (4)`. Native unit detection engine verified. |
| **9. Close without saving** | `doc.Close(EPcbCloseOptions.DO_NOT_SAVE = 0)`<br>`app.Quit()` | **UNVERIFIED\*** | Discards session without modifying or saving files on disk. SHA-256 and mtime protection verified. |
| **10. Run external scripts** | `powershell / python win32com Dispatch("MGCPCB.ExpeditionPCBApplication")`<br>`mgcscript.exe` | **UNVERIFIED\*** | External COM automation script bridge implemented. Automatic fallback to direct ASCII parser when Xpedition is not installed locally. |

*\*Note: Marked `UNVERIFIED` because Siemens Xpedition Layout 2510 is not installed on this local development sandbox. All methods are implemented per the official Siemens Xpedition Layout Automation Type Library specification and can be verified by executing against a licensed Xpedition 2510 workstation.*


---

## 3. Architecture & Codebase Structure

```text
E:\Creative\PCB\CUST-DOC\REV0.1\
├── app.py                          # Application entry point (GUI and CLI modes)
├── config.py                       # Global settings, constants, and supported units
├── README.md                       # Complete documentation & API investigation
│
├── xpedition/                      # Xpedition Automation & Extraction Engine
│   ├── __init__.py                 # Package exports
│   ├── models.py                   # Data models (Point, BoundingBox, LayerInfo, PCBInfo)
│   ├── api_definitions.py          # Siemens Xpedition 2510 COM ProgIDs, Enums & Matrix
│   ├── interface.py                # Abstract Base Class IPCBReader
│   ├── layer_detector.py           # Strict copper layer filtering & classification
│   ├── outline_detector.py         # Geometry bounding box, dimension & orientation math
│   ├── com_reader.py               # Live Siemens Xpedition Layout COM Automation reader
│   ├── direct_reader.py            # Direct ASCII/HKP design database reader (offline fallback)
│   ├── mock_reader.py              # Reference test simulation engine
│   └── extractor.py                # Main extractor coordinator and validator
│
├── ui/                             # Desktop Graphical User Interface (Tkinter / TTK)
│   ├── __init__.py
│   ├── theme.py                    # Modern clean theme, colors, typography
│   ├── components.py               # Reusable UI widgets (CardFrame, InfoField, StatusBadge, LogViewer)
│   └── main_window.py              # Main Application Window layout & event handlers
│
└── tests/                          # Automated Verification Suite (28 Tests)
    ├── __init__.py
    ├── run_all_tests.py            # Master test runner
    ├── test_models.py              # Unit tests for geometry, bounding box & models
    ├── test_layer_detector.py      # Unit tests for copper vs non-copper layer filtering
    ├── test_outline_detector.py    # Unit tests for rectangular & complex polygonal outlines
    ├── test_direct_reader.py       # Unit tests for direct Xpedition file parsing
    ├── test_protection.py          # Verification of SHA-256 and file timestamp protection
    ├── test_extractor.py           # Integration tests for extraction orchestrator
    └── sample_designs/             # Synthetic Xpedition reference datasets
        ├── 6layer_landscape.hkp    # 6-layer landscape board (120.50 x 85.25 mm, origin -10.25, 5.00)
        ├── 4layer_portrait.hkp     # 4-layer portrait board (75.00 x 140.00 mm, origin 0.00, 0.00)
        ├── 2layer_square.hkp       # 2-layer square board in mils (4000 x 4000 mil, origin 500, 500)
        ├── complex_outline.hkp     # 8-layer hexagonal polygon board (150.00 x 110.00 mm)
        ├── no_outline.hkp          # Design without board outline (missing outline test)
        └── invalid_format.txt      # Corrupted file test case
```

---

## 4. Dimension & Geometry Formulas

### Bounding Box Computation
Given a set of board outline vertices $\{(x_1, y_1), (x_2, y_2), \dots, (x_n, y_n)\}$:
$$\text{Xmin} = \min_{1 \le i \le n} x_i, \quad \text{Xmax} = \max_{1 \le i \le n} x_i$$
$$\text{Ymin} = \min_{1 \le i \le n} y_i, \quad \text{Ymax} = \max_{1 \le i \le n} y_i$$

### Board Dimensions
$$\text{Board Width} = \text{Xmax} - \text{Xmin}$$
$$\text{Board Height} = \text{Ymax} - \text{Ymin}$$

### Orientation Rule
$$\text{Orientation} = \begin{cases} 
\text{Landscape} & \text{if } \text{Board Width} > \text{Board Height} \\
\text{Portrait} & \text{if } \text{Board Height} > \text{Board Width} \\
\text{Square} & \text{if } \text{Board Width} = \text{Board Height}
\end{cases}$$

---

## 5. Copper Layer Filtering Rules

The application identifies genuine conductor layers and strictly rejects non-copper layers:

- **Included as Copper Layers:**
  - Signal Layers (`epcbLayerTypeSignal` / `ConductorSubtype.SIGNAL`)
  - Plane Layers (`epcbLayerTypePlane` / `ConductorSubtype.PLANE`)
  - Split Plane Layers (`epcbLayerTypeSplitPlane` / `ConductorSubtype.SPLIT_PLANE`)
  - Mixed Conductor Layers (`epcbLayerTypeMixed` / `ConductorSubtype.MIXED`)

- **Excluded Non-Copper Layers:**
  - Solder Mask (`epcbLayerTypeSolderMask`)
  - Paste Mask (`epcbLayerTypePasteMask`)
  - Silkscreen (`epcbLayerTypeSilkscreen`)
  - Assembly (`epcbLayerTypeAssembly`)
  - Documentation / Drill Drawing (`epcbLayerTypeDocumentation`)
  - User Layers (`epcbLayerTypeUser`)
  - Mechanical Layers / Keepouts / Cutouts (`epcbLayerTypeMechanical`)
  - Dielectric Layers (`epcbLayerTypeDielectric`)
  - DXF Geometry Layers (`epcbLayerTypeDxf`)

---

## 6. How to Run the Application

### Launch GUI Mode (Interactive Desktop Application)
```powershell
python E:\Creative\PCB\CUST-DOC\REV0.1\app.py
```

### Run CLI Mode (Batch or Headless Execution)
```powershell
# Format human-readable summary
python E:\Creative\PCB\CUST-DOC\REV0.1\app.py --file "E:\Creative\PCB\CUST-DOC\REV0.1\tests\sample_designs\6layer_landscape.hkp"

# Output structured JSON
python E:\Creative\PCB\CUST-DOC\REV0.1\app.py --file "E:\Creative\PCB\CUST-DOC\REV0.1\tests\sample_designs\6layer_landscape.hkp" --json
```

### Run Test Suite
```powershell
python E:\Creative\PCB\CUST-DOC\REV0.1\tests\run_all_tests.py
```

---

## 7. Sample Summary Output

```text
--------------------------------------------------
PCB INFORMATION
--------------------------------------------------
PCB Name:       DP-8001-TEST-V1
PCB File:       E:\Creative\PCB\CUST-DOC\REV0.1\tests\sample_designs\6layer_landscape.hkp
Native Unit:    mm
Copper Layers:  6
Layer Stack:
  1. TOP
  2. GND1
  3. PWR1
  4. SIG1
  5. SIG2
  6. BOTTOM
Board Outline:  Detected (5 vertices)
Board Width:    120.50 mm
Board Height:   85.25 mm
Board Origin:   X = -10.25 mm, Y = 5.00 mm
X Range:        -10.25 -> 110.25 mm
Y Range:        5.00 -> 90.25 mm
Orientation:    Landscape
Backend Engine: Xpedition Direct File Parser (Read-Only)
PCB Protected:  Yes (Read-Only)
--------------------------------------------------
```
