"""
Main Entry Point for Siemens Xpedition Layout PCB Reader & Information Extraction.

Project: E:\\Creative\\PCB\\CUST-DOC\\REV0.1
Version: 2510.1.0

Supports both full interactive GUI mode and headless CLI/automation mode.
"""

import sys
import os
import argparse
import json

# Ensure project root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import APP_NAME, APP_VERSION, APP_SUBTITLE
from xpedition import PCBInformationExtractor


def run_cli(file_path: str, backend: str = None, json_output: bool = False) -> int:
    """Run extraction in CLI / headless mode."""
    def cli_logger(level: str, msg: str):
        if not json_output:
            print(f"[{level.upper():<7}] {msg}")

    extractor = PCBInformationExtractor(log_cb=cli_logger, force_backend=backend)
    info = extractor.extract(file_path)

    if json_output:
        data = {
            "pcb_name": info.pcb_name,
            "file_path": info.file_path,
            "native_unit": info.native_unit,
            "total_copper_layers": info.total_copper_layers,
            "copper_layer_names": info.copper_layer_names,
            "board_outline_detected": info.board_outline_detected,
            "board_width": info.board_width,
            "board_height": info.board_height,
            "board_origin_x": info.board_origin_x,
            "board_origin_y": info.board_origin_y,
            "board_min_x": info.board_min_x,
            "board_max_x": info.board_max_x,
            "board_min_y": info.board_min_y,
            "board_max_y": info.board_max_y,
            "orientation": info.orientation,
            "reader_backend": info.reader_backend,
            "is_read_only": info.is_read_only,
            "extraction_successful": info.extraction_successful,
            "error_message": info.error_message
        }
        print(json.dumps(data, indent=2))
    else:
        print()
        print(info.format_summary())

    return 0 if info.extraction_successful else 1


def run_gui() -> None:
    """Launch the interactive Tkinter desktop GUI application."""
    from ui.main_window import MainWindow
    app = MainWindow()
    app.mainloop()


def main():
    parser = argparse.ArgumentParser(
        description=f"{APP_NAME} - {APP_SUBTITLE}",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--file", "-f", help="Path to Xpedition PCB file to read in CLI mode")
    parser.add_argument("--backend", "-b", choices=["com", "direct", "mock"], help="Force specific extraction backend")
    parser.add_argument("--json", "-j", action="store_true", help="Output extraction result as JSON (CLI mode)")
    parser.add_argument("--version", "-v", action="version", version=f"{APP_NAME} v{APP_VERSION}")

    args = parser.parse_args()

    if args.file:
        sys.exit(run_cli(args.file, backend=args.backend, json_output=args.json))
    else:
        run_gui()


if __name__ == "__main__":
    main()
