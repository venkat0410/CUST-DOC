import subprocess
import sys
import os

print("Python version:", sys.version)

ps_code = """
try {
    $app = New-Object -ComObject "MGCPCB.ExpeditionPCBApplication"
    Write-Host "MGCPCB COM exists: $app"
} catch {
    Write-Host "COM not registered on this host: $($_.Exception.Message)"
}
"""

res = subprocess.run(["powershell", "-NoProfile", "-Command", ps_code], capture_output=True, text=True)
print("PowerShell COM Test:", res.stdout.strip())
