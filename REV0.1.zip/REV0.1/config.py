"""
Configuration and constants for Xpedition Layout PCB Reader & Information Extraction.
Project location: E:\\Creative\\PCB\\CUST-DOC\\REV0.1
"""

import os

# Application Metadata
APP_NAME = "Siemens Xpedition Layout PCB Reader"
APP_SUBTITLE = "Step 1: PCB File Selection & Information Extraction"
APP_VERSION = "2510.1.0"
AUTHOR = "Documentation & Print Automation Team"

# Supported Native Units
UNIT_MM = "mm"
UNIT_MIL = "mil"
UNIT_INCH = "inch"
UNIT_MICRON = "um"

SUPPORTED_UNITS = [UNIT_MM, UNIT_MIL, UNIT_INCH, UNIT_MICRON]

# Orientation Constants
ORIENTATION_LANDSCAPE = "Landscape"
ORIENTATION_PORTRAIT = "Portrait"
ORIENTATION_SQUARE = "Square"
ORIENTATION_UNKNOWN = "Unknown"

# Outline Detection Status
OUTLINE_DETECTED = "Detected"
OUTLINE_NOT_DETECTED = "Not Detected"

# File Filter extensions for Xpedition designs
XPEDITION_FILE_EXTENSIONS = [
    ("Siemens Xpedition / Expedition PCB Files", "*.pcb;*.job;*.hkp;*.kpcb"),
    ("Xpedition PCB Database", "*.pcb"),
    ("Xpedition Job Files", "*.job"),
    ("Xpedition HKP Files", "*.hkp"),
    ("All Files", "*.*"),
]

# Log format
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
