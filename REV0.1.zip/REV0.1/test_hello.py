# Test script
print("Hello from project dir")
