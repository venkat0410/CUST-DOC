"""
Test suite package for Siemens Xpedition PCB Reader.
"""
