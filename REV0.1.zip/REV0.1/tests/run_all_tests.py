"""
Master Test Runner for Siemens Xpedition PCB Reader Test Suite.
Runs all unit, integration, and protection verification tests.
"""

import sys
import os
import unittest

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


def run_tests():
    loader = unittest.TestLoader()
    suite = loader.discover(os.path.dirname(__file__), pattern="test_*.py")

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 60)
    print(f"Test Run Summary:")
    print(f"  Tests Ran:  {result.testsRun}")
    print(f"  Failures:   {len(result.failures)}")
    print(f"  Errors:     {len(result.errors)}")
    print(f"  Passed:     {result.testsRun - len(result.failures) - len(result.errors)}")
    print("=" * 60)

    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(run_tests())
