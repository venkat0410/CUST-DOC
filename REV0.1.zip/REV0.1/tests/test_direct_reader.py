"""
Unit tests for Direct Xpedition File Reader.
"""

import os
import unittest
from xpedition.direct_reader import XpeditionDirectFileReader

SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "sample_designs")


class TestDirectReader(unittest.TestCase):

    def setUp(self):
        self.reader = XpeditionDirectFileReader()

    def test_read_6layer_landscape(self):
        path = os.path.join(SAMPLE_DIR, "6layer_landscape.hkp")
        info = self.reader.read_pcb(path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 6)
        self.assertEqual(info.copper_layer_names, ["TOP", "GND1", "PWR1", "SIG1", "SIG2", "BOTTOM"])
        self.assertTrue(info.board_outline_detected)
        self.assertAlmostEqual(info.board_width, 120.50, places=2)
        self.assertAlmostEqual(info.board_height, 85.25, places=2)
        self.assertAlmostEqual(info.board_origin_x, -10.25, places=2)
        self.assertAlmostEqual(info.board_origin_y, 5.00, places=2)
        self.assertEqual(info.orientation, "Landscape")
        self.assertEqual(info.native_unit, "mm")
        self.assertTrue(info.is_read_only)

    def test_read_4layer_portrait(self):
        path = os.path.join(SAMPLE_DIR, "4layer_portrait.hkp")
        info = self.reader.read_pcb(path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 4)
        self.assertEqual(info.copper_layer_names, ["TOP", "INNER1_GND", "INNER2_PWR", "BOTTOM"])
        self.assertTrue(info.board_outline_detected)
        self.assertAlmostEqual(info.board_width, 75.00, places=2)
        self.assertAlmostEqual(info.board_height, 140.00, places=2)
        self.assertEqual(info.orientation, "Portrait")

    def test_read_2layer_square(self):
        path = os.path.join(SAMPLE_DIR, "2layer_square.hkp")
        info = self.reader.read_pcb(path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 2)
        self.assertEqual(info.copper_layer_names, ["TOP", "BOTTOM"])
        self.assertTrue(info.board_outline_detected)
        self.assertAlmostEqual(info.board_width, 4000.00, places=2)
        self.assertAlmostEqual(info.board_height, 4000.00, places=2)
        self.assertEqual(info.orientation, "Square")
        self.assertEqual(info.native_unit, "mil")

    def test_read_complex_outline(self):
        path = os.path.join(SAMPLE_DIR, "complex_outline.hkp")
        info = self.reader.read_pcb(path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 8)
        self.assertTrue(info.board_outline_detected)
        self.assertAlmostEqual(info.board_width, 150.00, places=2)
        self.assertAlmostEqual(info.board_height, 110.00, places=2)
        self.assertEqual(info.orientation, "Landscape")

    def test_read_no_outline(self):
        path = os.path.join(SAMPLE_DIR, "no_outline.hkp")
        info = self.reader.read_pcb(path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 2)
        self.assertFalse(info.board_outline_detected)

    def test_read_non_existent_file(self):
        info = self.reader.read_pcb(r"E:\Creative\PCB\does_not_exist_9999.pcb")
        self.assertFalse(info.extraction_successful)
        self.assertIn("Unable to read PCB file", info.error_message)

    def test_read_invalid_format_file(self):
        path = os.path.join(SAMPLE_DIR, "invalid_format.txt")
        info = self.reader.read_pcb(path)
        self.assertFalse(info.extraction_successful)
        self.assertIn("Unable to read PCB file", info.error_message)

    def test_read_empty_file(self):
        empty_path = os.path.join(SAMPLE_DIR, "empty_temp.hkp")
        with open(empty_path, "w") as f:
            f.write("")
        try:
            info = self.reader.read_pcb(empty_path)
            self.assertFalse(info.extraction_successful)
            self.assertIn("Unable to read PCB file", info.error_message)
        finally:
            if os.path.exists(empty_path):
                os.remove(empty_path)


if __name__ == "__main__":
    unittest.main()

