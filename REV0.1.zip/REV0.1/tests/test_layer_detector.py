"""
Unit tests for Copper Layer Detection and Non-Copper Layer Exclusion.
"""

import unittest
from xpedition.layer_detector import LayerDetector
from xpedition.models import LayerInfo, LayerClass, ConductorSubtype
from xpedition.api_definitions import EPcbLayerType, EPcbLayerClass


class TestLayerDetector(unittest.TestCase):

    def test_official_api_layer_types(self):
        # Conductor types
        sig = LayerDetector.classify_from_api("TOP", 1, EPcbLayerType.SIGNAL)
        self.assertTrue(sig.is_copper)
        self.assertEqual(sig.layer_class, LayerClass.CONDUCTOR)
        self.assertEqual(sig.conductor_subtype, ConductorSubtype.SIGNAL)

        plane = LayerDetector.classify_from_api("GND1", 2, EPcbLayerType.PLANE)
        self.assertTrue(plane.is_copper)
        self.assertEqual(plane.conductor_subtype, ConductorSubtype.PLANE)

        split = LayerDetector.classify_from_api("PWR_SPLIT", 3, EPcbLayerType.SPLIT_PLANE)
        self.assertTrue(split.is_copper)
        self.assertEqual(split.conductor_subtype, ConductorSubtype.SPLIT_PLANE)

        mixed = LayerDetector.classify_from_api("MIXED_3", 4, EPcbLayerType.MIXED)
        self.assertTrue(mixed.is_copper)
        self.assertEqual(mixed.conductor_subtype, ConductorSubtype.MIXED)

        # Non-copper types MUST NOT be counted
        silk = LayerDetector.classify_from_api("Silkscreen Top", 5, EPcbLayerType.SILKSCREEN)
        self.assertFalse(silk.is_copper)

        mask = LayerDetector.classify_from_api("SolderMask Top", 6, EPcbLayerType.SOLDER_MASK)
        self.assertFalse(mask.is_copper)

        paste = LayerDetector.classify_from_api("PasteMask Top", 7, EPcbLayerType.PASTE_MASK)
        self.assertFalse(paste.is_copper)

        assy = LayerDetector.classify_from_api("Assembly Top", 8, EPcbLayerType.ASSEMBLY)
        self.assertFalse(assy.is_copper)

        doc = LayerDetector.classify_from_api("Drill Drawing", 9, EPcbLayerType.DOCUMENTATION)
        self.assertFalse(doc.is_copper)

        user = LayerDetector.classify_from_api("User Layer 1", 10, EPcbLayerType.USER)
        self.assertFalse(user.is_copper)

        mech = LayerDetector.classify_from_api("Mechanical Cutout", 11, EPcbLayerType.MECHANICAL)
        self.assertFalse(mech.is_copper)

        dxf = LayerDetector.classify_from_api("DXF Border", 12, EPcbLayerType.DXF)
        self.assertFalse(dxf.is_copper)

        dielectric = LayerDetector.classify_from_api("Core FR4", 13, EPcbLayerType.DIELECTRIC)
        self.assertFalse(dielectric.is_copper)

    def test_layer_filtering_stack(self):
        stack = [
            LayerDetector.classify_from_api("TOP", 1, EPcbLayerType.SIGNAL),
            LayerDetector.classify_from_api("Silkscreen Top", 2, EPcbLayerType.SILKSCREEN),
            LayerDetector.classify_from_api("SolderMask Top", 3, EPcbLayerType.SOLDER_MASK),
            LayerDetector.classify_from_api("GND1", 4, EPcbLayerType.PLANE),
            LayerDetector.classify_from_api("Core 1", 5, EPcbLayerType.DIELECTRIC),
            LayerDetector.classify_from_api("PWR1", 6, EPcbLayerType.PLANE),
            LayerDetector.classify_from_api("Prepreg 1", 7, EPcbLayerType.DIELECTRIC),
            LayerDetector.classify_from_api("SIG1", 8, EPcbLayerType.SIGNAL),
            LayerDetector.classify_from_api("Core 2", 9, EPcbLayerType.DIELECTRIC),
            LayerDetector.classify_from_api("SIG2", 10, EPcbLayerType.SIGNAL),
            LayerDetector.classify_from_api("Prepreg 2", 11, EPcbLayerType.DIELECTRIC),
            LayerDetector.classify_from_api("BOTTOM", 12, EPcbLayerType.SIGNAL),
            LayerDetector.classify_from_api("User Notes", 13, EPcbLayerType.USER),
            LayerDetector.classify_from_api("DXF Title", 14, EPcbLayerType.DXF),
        ]
        copper_layers = LayerDetector.filter_copper_layers(stack)
        self.assertEqual(len(copper_layers), 6)
        names = [l.name for l in copper_layers]
        self.assertEqual(names, ["TOP", "GND1", "PWR1", "SIG1", "SIG2", "BOTTOM"])

    def test_name_based_classification(self):
        # Copper tests
        is_cop, lc, st = LayerDetector.classify_by_name("TOP")
        self.assertTrue(is_cop)
        self.assertEqual(lc, LayerClass.CONDUCTOR)

        is_cop, lc, st = LayerDetector.classify_by_name("Inner 3")
        self.assertTrue(is_cop)

        is_cop, lc, st = LayerDetector.classify_by_name("GND_PLANE")
        self.assertTrue(is_cop)

        # Non-copper tests
        is_cop, lc, st = LayerDetector.classify_by_name("Silkscreen_Top")
        self.assertFalse(is_cop)

        is_cop, lc, st = LayerDetector.classify_by_name("User_Layer_Notes")
        self.assertFalse(is_cop)

    def test_token_based_classification(self):
        # Conductor tokens override misleading names
        l1 = LayerDetector.classify_from_tokens("Custom User Layer", 1, type_token="CONDUCTOR SIGNAL")
        self.assertTrue(l1.is_copper)
        self.assertEqual(l1.layer_class, LayerClass.CONDUCTOR)
        self.assertEqual(l1.conductor_subtype, ConductorSubtype.SIGNAL)

        # Mechanical token overrides conductor-like name
        l2 = LayerDetector.classify_from_tokens("Layer 5 Conductor Spare", 2, type_token="MECHANICAL")
        self.assertFalse(l2.is_copper)
        self.assertEqual(l2.layer_class, LayerClass.MECHANICAL)

        # Plane token
        l3 = LayerDetector.classify_from_tokens("GND_PLANE", 3, type_token="CONDUCTOR PLANE")
        self.assertTrue(l3.is_copper)
        self.assertEqual(l3.conductor_subtype, ConductorSubtype.PLANE)

        # Split plane token
        l4 = LayerDetector.classify_from_tokens("VCC_SPLIT", 4, type_token="CONDUCTOR SPLIT_PLANE")
        self.assertTrue(l4.is_copper)
        self.assertEqual(l4.conductor_subtype, ConductorSubtype.SPLIT_PLANE)

        # Mixed token
        l5 = LayerDetector.classify_from_tokens("MIXED_ROUTING", 5, type_token="CONDUCTOR MIXED")
        self.assertTrue(l5.is_copper)
        self.assertEqual(l5.conductor_subtype, ConductorSubtype.MIXED)

        # Solder mask token
        l6 = LayerDetector.classify_from_tokens("Mask Top", 6, type_token="SOLDERMASK")
        self.assertFalse(l6.is_copper)
        self.assertEqual(l6.layer_class, LayerClass.SOLDER_MASK)


if __name__ == "__main__":
    unittest.main()

