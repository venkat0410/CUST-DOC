"""
Unit tests for geometric models, bounding box calculations, and orientation rules.
"""

import unittest
from xpedition.models import Point, BoundingBox, PCBInfo, LayerInfo, LayerClass


class TestModels(unittest.TestCase):

    def test_point_creation(self):
        pt = Point(12.5, -4.2)
        self.assertEqual(pt.x, 12.5)
        self.assertEqual(pt.y, -4.2)
        self.assertEqual(pt.as_tuple(), (12.5, -4.2))
        x, y = pt
        self.assertEqual((x, y), (12.5, -4.2))

    def test_bounding_box_landscape(self):
        bbox = BoundingBox(min_x=-10.25, max_x=110.25, min_y=5.00, max_y=90.25)
        self.assertAlmostEqual(bbox.width, 120.50, places=2)
        self.assertAlmostEqual(bbox.height, 85.25, places=2)
        self.assertEqual(bbox.orientation, "Landscape")

    def test_bounding_box_portrait(self):
        bbox = BoundingBox(min_x=0.0, max_x=75.0, min_y=0.0, max_y=140.0)
        self.assertAlmostEqual(bbox.width, 75.0, places=2)
        self.assertAlmostEqual(bbox.height, 140.0, places=2)
        self.assertEqual(bbox.orientation, "Portrait")

    def test_bounding_box_square(self):
        bbox = BoundingBox(min_x=50.0, max_x=150.0, min_y=20.0, max_y=120.0)
        self.assertAlmostEqual(bbox.width, 100.0, places=2)
        self.assertAlmostEqual(bbox.height, 100.0, places=2)
        self.assertEqual(bbox.orientation, "Square")

    def test_negative_coordinates(self):
        bbox = BoundingBox(min_x=-150.0, max_x=-50.0, min_y=-80.0, max_y=-20.0)
        self.assertAlmostEqual(bbox.width, 100.0, places=2)
        self.assertAlmostEqual(bbox.height, 60.0, places=2)
        self.assertEqual(bbox.orientation, "Landscape")

    def test_pcb_info_summary_formatting(self):
        info = PCBInfo(
            pcb_name="DP-TEST-BOARD",
            file_path=r"E:\Creative\PCB\test.pcb",
            native_unit="mm",
            total_copper_layers=6,
            copper_layer_names=["TOP", "GND1", "PWR1", "SIG1", "SIG2", "BOTTOM"],
            board_outline_detected=True,
            board_origin_x=-10.25,
            board_origin_y=5.00,
            board_min_x=-10.25,
            board_max_x=110.25,
            board_min_y=5.00,
            board_max_y=90.25,
            board_width=120.50,
            board_height=85.25,
            orientation="Landscape",
            reader_backend="Test Engine",
            is_read_only=True
        )
        summary = info.format_summary()
        self.assertIn("DP-TEST-BOARD", summary)
        self.assertIn("Copper Layers:  6", summary)
        self.assertIn("Board Width:    120.50 mm", summary)
        self.assertIn("Board Height:   85.25 mm", summary)
        self.assertIn("Orientation:    Landscape", summary)
        self.assertIn("1. TOP", summary)
        self.assertIn("6. BOTTOM", summary)
        self.assertIn("PCB Protected:  Yes (Read-Only)", summary)


    def test_bounding_box_degenerate_zero(self):
        bbox = BoundingBox(min_x=0.0, max_x=0.0, min_y=0.0, max_y=0.0)
        self.assertEqual(bbox.width, 0.0)
        self.assertEqual(bbox.height, 0.0)
        self.assertEqual(bbox.orientation, "Unknown")


if __name__ == "__main__":
    unittest.main()

