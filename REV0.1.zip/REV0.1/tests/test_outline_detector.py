"""
Unit tests for Board Outline Detection, Polygon Bounding Box, and Dimension Calculations.
"""

import unittest
from xpedition.outline_detector import OutlineDetector
from xpedition.models import Point, BoundingBox


class TestOutlineDetector(unittest.TestCase):

    def test_standard_rectangle_outline(self):
        pts = [
            Point(-10.25, 5.00),
            Point(110.25, 5.00),
            Point(110.25, 90.25),
            Point(-10.25, 90.25),
            Point(-10.25, 5.00),
        ]
        self.assertTrue(OutlineDetector.validate_outline(pts))
        bbox = OutlineDetector.calculate_bounding_box(pts)
        self.assertIsNotNone(bbox)
        self.assertAlmostEqual(bbox.min_x, -10.25, places=2)
        self.assertAlmostEqual(bbox.max_x, 110.25, places=2)
        self.assertAlmostEqual(bbox.min_y, 5.00, places=2)
        self.assertAlmostEqual(bbox.max_y, 90.25, places=2)

        w, h, ori = OutlineDetector.calculate_dimensions(bbox)
        self.assertAlmostEqual(w, 120.50, places=2)
        self.assertAlmostEqual(h, 85.25, places=2)
        self.assertEqual(ori, "Landscape")

    def test_complex_hexagonal_polygon_outline(self):
        # 6-point polygon
        pts = [
            Point(0.0, -15.0),
            Point(100.0, -15.0),
            Point(125.0, 40.0),
            Point(100.0, 95.0),
            Point(0.0, 95.0),
            Point(-25.0, 40.0),
            Point(0.0, -15.0),
        ]
        self.assertTrue(OutlineDetector.validate_outline(pts))
        bbox = OutlineDetector.calculate_bounding_box(pts)
        self.assertIsNotNone(bbox)
        self.assertAlmostEqual(bbox.min_x, -25.00, places=2)
        self.assertAlmostEqual(bbox.max_x, 125.00, places=2)
        self.assertAlmostEqual(bbox.min_y, -15.00, places=2)
        self.assertAlmostEqual(bbox.max_y, 95.00, places=2)

        w, h, ori = OutlineDetector.calculate_dimensions(bbox)
        self.assertAlmostEqual(w, 150.00, places=2)
        self.assertAlmostEqual(h, 110.00, places=2)
        self.assertEqual(ori, "Landscape")

    def test_portrait_outline(self):
        pts = [
            Point(0.0, 0.0),
            Point(75.0, 0.0),
            Point(75.0, 140.0),
            Point(0.0, 140.0),
            Point(0.0, 0.0),
        ]
        bbox = OutlineDetector.calculate_bounding_box(pts)
        w, h, ori = OutlineDetector.calculate_dimensions(bbox)
        self.assertAlmostEqual(w, 75.00, places=2)
        self.assertAlmostEqual(h, 140.00, places=2)
        self.assertEqual(ori, "Portrait")

    def test_square_outline(self):
        pts = [
            Point(10.0, 10.0),
            Point(110.0, 10.0),
            Point(110.0, 110.0),
            Point(10.0, 110.0),
            Point(10.0, 10.0),
        ]
        bbox = OutlineDetector.calculate_bounding_box(pts)
        w, h, ori = OutlineDetector.calculate_dimensions(bbox)
        self.assertAlmostEqual(w, 100.00, places=2)
        self.assertAlmostEqual(h, 100.00, places=2)
        self.assertEqual(ori, "Square")

    def test_empty_or_degenerate_outlines(self):
        self.assertIsNone(OutlineDetector.calculate_bounding_box([]))
        self.assertFalse(OutlineDetector.validate_outline([]))
        
        # Collinear points (no area)
        collinear = [Point(0, 0), Point(10, 0), Point(20, 0)]
        self.assertFalse(OutlineDetector.validate_outline(collinear))


if __name__ == "__main__":
    unittest.main()
