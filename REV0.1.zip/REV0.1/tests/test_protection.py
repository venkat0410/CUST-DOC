"""
Verification of Original PCB Protection and Read-Only Invariants.

Guarantees that reading a PCB never modifies file timestamps, file content,
or SHA-256 hashes of the original PCB design files.
"""

import os
import hashlib
import unittest
from xpedition import PCBInformationExtractor, XpeditionDirectFileReader, MockXpeditionReader

SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "sample_designs")


def compute_file_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()


class TestOriginalPCBProtection(unittest.TestCase):

    def test_file_integrity_after_extraction(self):
        sample_files = [
            "6layer_landscape.hkp",
            "4layer_portrait.hkp",
            "2layer_square.hkp",
            "complex_outline.hkp"
        ]

        extractor = PCBInformationExtractor()

        for fname in sample_files:
            file_path = os.path.join(SAMPLE_DIR, fname)
            
            # Record state before extraction
            stat_before = os.stat(file_path)
            hash_before = compute_file_hash(file_path)
            mtime_before = stat_before.st_mtime_ns
            size_before = stat_before.st_size

            # Perform extraction
            info = extractor.extract(file_path)

            # Record state after extraction
            stat_after = os.stat(file_path)
            hash_after = compute_file_hash(file_path)
            mtime_after = stat_after.st_mtime_ns
            size_after = stat_after.st_size

            # Assert complete integrity
            self.assertEqual(hash_before, hash_after, f"File hash modified for {fname}!")
            self.assertEqual(mtime_before, mtime_after, f"File mtime modified for {fname}!")
            self.assertEqual(size_before, size_after, f"File size modified for {fname}!")
            self.assertTrue(info.is_read_only, "is_read_only flag must always be True")


if __name__ == "__main__":
    unittest.main()
