"""
Reusable UI Components and Widgets for the PCB Reader Interface.
"""

import tkinter as tk
from tkinter import ttk
from datetime import datetime
from typing import Optional
from .theme import (
    COLOR_CARD_BG,
    COLOR_CARD_BORDER,
    COLOR_TEXT_LABEL,
    COLOR_TEXT_MAIN,
    COLOR_TEXT_MUTED,
    COLOR_SUCCESS_BG,
    COLOR_SUCCESS_FG,
    COLOR_SUCCESS_BORDER,
    COLOR_WARNING_BG,
    COLOR_WARNING_FG,
    COLOR_WARNING_BORDER,
    COLOR_ERROR_BG,
    COLOR_ERROR_FG,
    COLOR_ERROR_BORDER,
    COLOR_CONSOLE_BG,
    COLOR_CONSOLE_FG,
    COLOR_CONSOLE_INFO,
    COLOR_CONSOLE_WARN,
    COLOR_CONSOLE_ERR,
    COLOR_CONSOLE_SUCCESS,
    FONT_LABEL,
    FONT_VALUE,
    FONT_VALUE_EMPHASIS,
    FONT_SECTION_TITLE,
    FONT_MONO_LOG,
    FONT_BADGE,
)


class CardFrame(tk.Frame):
    """Container frame styled as a modern elevated card."""

    def __init__(self, parent, title: Optional[str] = None, *args, **kwargs):
        super().__init__(
            parent,
            bg=COLOR_CARD_BG,
            highlightbackground=COLOR_CARD_BORDER,
            highlightthickness=1,
            padx=16,
            pady=14,
            *args,
            **kwargs
        )
        if title:
            self.title_label = tk.Label(
                self,
                text=title,
                font=FONT_SECTION_TITLE,
                bg=COLOR_CARD_BG,
                fg=COLOR_TEXT_MAIN,
                anchor="w"
            )
            self.title_label.pack(fill="x", pady=(0, 10))


class InfoField(tk.Frame):
    """Key-value display pair with crisp label and dynamic value."""

    def __init__(self, parent, label: str, default_value: str = "-", is_emphasis: bool = False, *args, **kwargs):
        super().__init__(parent, bg=COLOR_CARD_BG, *args, **kwargs)
        
        self.label = tk.Label(
            self,
            text=label,
            font=FONT_LABEL,
            fg=COLOR_TEXT_MUTED,
            bg=COLOR_CARD_BG,
            anchor="w"
        )
        self.label.pack(fill="x")

        font = FONT_VALUE_EMPHASIS if is_emphasis else FONT_VALUE
        self.value_var = tk.StringVar(value=default_value)
        self.value_label = tk.Label(
            self,
            textvariable=self.value_var,
            font=font,
            fg=COLOR_TEXT_MAIN,
            bg=COLOR_CARD_BG,
            anchor="w",
            wraplength=350,
            justify="left"
        )
        self.value_label.pack(fill="x", pady=(2, 0))

    def set_value(self, val: str) -> None:
        self.value_var.set(val)

    def get_value(self) -> str:
        return self.value_var.get()


class StatusBadge(tk.Frame):
    """Pill-style badge for status, orientation, and detection indicators."""

    def __init__(self, parent, text: str = "Unknown", status_type: str = "neutral", *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.label = tk.Label(self, text=f" {text} ", font=FONT_BADGE, padx=8, pady=3)
        self.label.pack()
        self.set_status(text, status_type)

    def set_status(self, text: str, status_type: str = "neutral") -> None:
        self.label.config(text=f" {text} ")
        if status_type == "success":
            bg, fg, border = COLOR_SUCCESS_BG, COLOR_SUCCESS_FG, COLOR_SUCCESS_BORDER
        elif status_type == "warning":
            bg, fg, border = COLOR_WARNING_BG, COLOR_WARNING_FG, COLOR_WARNING_BORDER
        elif status_type == "error":
            bg, fg, border = COLOR_ERROR_BG, COLOR_ERROR_FG, COLOR_ERROR_BORDER
        else:
            bg, fg, border = "#f1f5f9", "#475569", "#cbd5e1"

        self.config(bg=border, padx=1, pady=1)
        self.label.config(bg=bg, fg=fg)


class ConsoleLogViewer(tk.Frame):
    """Monospace live debug log viewer with syntax tagging and auto-scroll."""

    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, bg=COLOR_CONSOLE_BG, *args, **kwargs)

        # Toolbar
        self.toolbar = tk.Frame(self, bg=COLOR_CONSOLE_BG)
        self.toolbar.pack(fill="x", padx=8, pady=(6, 2))

        self.title_lbl = tk.Label(
            self.toolbar,
            text="Debug & Automation Execution Log",
            font=(FONT_LABEL[0], 9, "bold"),
            bg=COLOR_CONSOLE_BG,
            fg="#94a3b8"
        )
        self.title_lbl.pack(side="left")

        self.clear_btn = tk.Button(
            self.toolbar,
            text="Clear Log",
            font=(FONT_LABEL[0], 8),
            bg="#1e293b",
            fg="#94a3b8",
            activebackground="#334155",
            activeforeground="#ffffff",
            bd=0,
            padx=6,
            pady=2,
            command=self.clear
        )
        self.clear_btn.pack(side="right")

        # Text & Scrollbar
        self.text_frame = tk.Frame(self, bg=COLOR_CONSOLE_BG)
        self.text_frame.pack(fill="both", expand=True, padx=8, pady=(0, 6))

        self.scrollbar = tk.Scrollbar(self.text_frame)
        self.scrollbar.pack(side="right", fill="y")

        self.text = tk.Text(
            self.text_frame,
            bg=COLOR_CONSOLE_BG,
            fg=COLOR_CONSOLE_FG,
            font=FONT_MONO_LOG,
            wrap="word",
            yscrollcommand=self.scrollbar.set,
            height=9,
            bd=0,
            padx=6,
            pady=6
        )
        self.text.pack(side="left", fill="both", expand=True)
        self.scrollbar.config(command=self.text.yview)

        # Configure color tags
        self.text.tag_config("timestamp", foreground="#64748b")
        self.text.tag_config("info_tag", foreground=COLOR_CONSOLE_INFO)
        self.text.tag_config("warn_tag", foreground=COLOR_CONSOLE_WARN)
        self.text.tag_config("err_tag", foreground=COLOR_CONSOLE_ERR)
        self.text.tag_config("succ_tag", foreground=COLOR_CONSOLE_SUCCESS)
        self.text.tag_config("msg", foreground=COLOR_CONSOLE_FG)

    def log(self, level: str, message: str) -> None:
        """Append a colorized log line."""
        now_str = datetime.now().strftime("%H:%M:%S")
        self.text.config(state="normal")
        
        self.text.insert("end", f"[{now_str}] ", "timestamp")
        
        tag = "info_tag"
        if level.upper() == "INFO":
            tag = "info_tag"
        elif level.upper() in ["WARN", "WARNING"]:
            tag = "warn_tag"
        elif level.upper() == "ERROR":
            tag = "err_tag"
        elif level.upper() == "SUCCESS":
            tag = "succ_tag"

        self.text.insert("end", f"[{level.upper()}] ", tag)
        self.text.insert("end", f"{message}\n", "msg")
        self.text.see("end")
        self.text.config(state="disabled")

    def clear(self) -> None:
        """Clear all log entries."""
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        self.text.config(state="disabled")
