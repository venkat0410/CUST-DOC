"""
UI Theme and Styling Constants for Siemens Xpedition PCB Reader.
"""

# Color Palette (Modern Clean Enterprise Aesthetic)
COLOR_BG = "#f8fafc"            # Slate 50
COLOR_CARD_BG = "#ffffff"       # Pure white
COLOR_CARD_BORDER = "#e2e8f0"   # Slate 200
COLOR_HEADER_BG = "#0f172a"     # Slate 900
COLOR_HEADER_FG = "#f8fafc"     # Slate 50
COLOR_HEADER_SUB = "#94a3b8"    # Slate 400

COLOR_PRIMARY = "#2563eb"       # Blue 600
COLOR_PRIMARY_HOVER = "#1d4ed8" # Blue 700
COLOR_PRIMARY_FG = "#ffffff"

COLOR_SECONDARY = "#475569"     # Slate 600
COLOR_SECONDARY_HOVER = "#334155" # Slate 700
COLOR_SECONDARY_FG = "#ffffff"

COLOR_SUCCESS_BG = "#dcfce7"    # Green 100
COLOR_SUCCESS_FG = "#15803d"    # Green 700
COLOR_SUCCESS_BORDER = "#86efac"# Green 300

COLOR_WARNING_BG = "#fef3c7"    # Amber 100
COLOR_WARNING_FG = "#b45309"    # Amber 700
COLOR_WARNING_BORDER = "#fde68a"# Amber 300

COLOR_ERROR_BG = "#fee2e2"      # Red 100
COLOR_ERROR_FG = "#b91c1c"      # Red 700
COLOR_ERROR_BORDER = "#fca5a5"  # Red 300

COLOR_TEXT_MAIN = "#0f172a"     # Slate 900
COLOR_TEXT_MUTED = "#64748b"    # Slate 500
COLOR_TEXT_LABEL = "#334155"    # Slate 700

COLOR_CONSOLE_BG = "#0f172a"    # Slate 900
COLOR_CONSOLE_FG = "#e2e8f0"    # Slate 200
COLOR_CONSOLE_INFO = "#38bdf8"  # Sky 400
COLOR_CONSOLE_WARN = "#facc15"  # Yellow 400
COLOR_CONSOLE_ERR = "#f87171"   # Red 400
COLOR_CONSOLE_SUCCESS = "#4ade80" # Green 400

# Typography
FONT_FAMILY = "Segoe UI"
FONT_MONO = "Consolas"

FONT_HEADER = (FONT_FAMILY, 15, "bold")
FONT_SUBHEADER = (FONT_FAMILY, 9)
FONT_SECTION_TITLE = (FONT_FAMILY, 11, "bold")
FONT_BODY = (FONT_FAMILY, 10)
FONT_BODY_BOLD = (FONT_FAMILY, 10, "bold")
FONT_LABEL = (FONT_FAMILY, 9, "bold")
FONT_VALUE = (FONT_FAMILY, 10)
FONT_VALUE_EMPHASIS = (FONT_FAMILY, 11, "bold")
FONT_MONO_LOG = (FONT_MONO, 9)
FONT_BADGE = (FONT_FAMILY, 9, "bold")
