"""
Siemens Xpedition Layout 2510 PCB Reader & Information Extraction Package.
"""

from .models import (
    Point,
    BoundingBox,
    LayerClass,
    ConductorSubtype,
    LayerInfo,
    PCBInfo,
)
from .api_definitions import (
    EPcbUnit,
    EPcbLayerType,
    EPcbLayerClass,
    EPcbCloseOptions,
    API_INVESTIGATION_MATRIX,
)
from .interface import IPCBReader, LogCallback
from .layer_detector import LayerDetector
from .outline_detector import OutlineDetector
from .com_reader import XpeditionCOMReader
from .direct_reader import XpeditionDirectFileReader
from .mock_reader import MockXpeditionReader
from .extractor import PCBInformationExtractor

__all__ = [
    "Point",
    "BoundingBox",
    "LayerClass",
    "ConductorSubtype",
    "LayerInfo",
    "PCBInfo",
    "EPcbUnit",
    "EPcbLayerType",
    "EPcbLayerClass",
    "EPcbCloseOptions",
    "API_INVESTIGATION_MATRIX",
    "IPCBReader",
    "LogCallback",
    "LayerDetector",
    "OutlineDetector",
    "XpeditionCOMReader",
    "XpeditionDirectFileReader",
    "MockXpeditionReader",
    "PCBInformationExtractor",
]
