"""
Direct Xpedition ASCII / HKP File Reader (Offline & Diagnostic Fallback).

Parses Siemens Xpedition ASCII databases, .hkp, .pcb, and layout database files
directly in 100% read-only mode without modifying the file.
"""

import os
import re
from typing import Optional, List, Tuple
from .interface import IPCBReader, LogCallback
from .models import PCBInfo, Point, LayerInfo, LayerClass, ConductorSubtype
from .layer_detector import LayerDetector
from .outline_detector import OutlineDetector


class XpeditionDirectFileReader(IPCBReader):
    """
    Direct parser for Xpedition ASCII/HKP design files.
    """

    def is_available(self) -> bool:
        """Direct file parser is always available."""
        return True

    def read_pcb(self, file_path: str) -> PCBInfo:
        """
        Reads an Xpedition PCB/HKP file directly in read-only mode.
        """
        abs_path = os.path.abspath(file_path)
        pcb_name = os.path.splitext(os.path.basename(file_path))[0]
        
        info = PCBInfo(
            pcb_name=pcb_name,
            file_path=abs_path,
            reader_backend="Xpedition Direct File Parser (Read-Only)",
            is_read_only=True
        )

        if not os.path.exists(abs_path):
            self.log("ERROR", f"PCB file not found: {abs_path}")
            info.extraction_successful = False
            info.error_message = f"Unable to read PCB file: File does not exist ({abs_path})."
            return info

        self.log("INFO", f"PCB selected: {abs_path}")
        self.log("INFO", "Opening PCB in Read-Only mode...")

        try:
            # Check for binary file (contains null bytes)
            with open(abs_path, "rb") as bf:
                chunk = bf.read(1024)
                if b"\x00" in chunk:
                    self.log("ERROR", "Binary PCB file detected. Direct ASCII parser requires ASCII/HKP format.")
                    info.extraction_successful = False
                    info.error_message = "PCB format or Xpedition API interface could not be accessed. (Xpedition Layout COM Automation is required to read binary .pcb files)"
                    return info

            with open(abs_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            if not content.strip():
                self.log("ERROR", "PCB file is empty.")
                info.extraction_successful = False
                info.error_message = "Unable to read PCB file: File is empty."
                return info

            is_valid = self._parse_file_content(content, info)
            if not is_valid:
                self.log("ERROR", "File does not contain valid Xpedition PCB structure.")
                info.extraction_successful = False
                info.error_message = "Unable to read PCB file: Invalid or unsupported PCB format."
                return info

            info.extraction_successful = True
            self.log("INFO", "PCB closed without saving (Original PCB protected)")
            return info

        except Exception as ex:
            self.log("ERROR", f"Error parsing PCB file: {str(ex)}")
            info.extraction_successful = False
            info.error_message = f"Unable to read PCB file: {str(ex)}"
            return info

    def _parse_file_content(self, content: str, info: PCBInfo) -> bool:
        """
        Parse units, layers, origin, and outline from text content.
        Returns True if the content is a valid Xpedition PCB file, False otherwise.
        """
        lines = content.splitlines()

        # Check for Xpedition markers / keywords
        xpedition_keywords = [
            "..FILE_TYPE", "..VERSION", "..DESIGN_NAME", "..UNITS",
            "..LAYER_STACKUP", "..STACKUP", ".STACK", "..CONDUCTOR_LAYER",
            "..BOARD_OUTLINE", "..ROUTE_BORDER", "..BOARD_BORDER", "..OUTLINE",
            "..ORIGIN", ".ORIGIN", ".LAYER", ".PT"
        ]
        has_marker = any(
            any(k in line.strip().upper() for k in xpedition_keywords)
            for line in lines
        )

        if not has_marker:
            return False

        # 1. Parse Design Name if present
        for line in lines:
            line_strip = line.strip()
            line_upper = line_strip.upper()
            if line_upper.startswith("..DESIGN_NAME") or line_upper.startswith(".NAME"):
                m = re.search(r'["\']([^"\']+)["\']', line_strip)
                if m:
                    info.pcb_name = m.group(1).strip()
                else:
                    parts = line_strip.split(maxsplit=1)
                    if len(parts) > 1:
                        info.pcb_name = parts[1].strip()
                break

        # 2. Parse Units
        unit = "mm"
        for line in lines:
            line_upper = line.strip().upper()
            if line_upper.startswith("..UNITS") or line_upper.startswith("UNITS") or line_upper.startswith(".UNITS"):
                if any(u in line_upper for u in ["TH", "MIL", "THOU", "MILS"]):
                    unit = "mil"
                elif "IN" in line_upper:
                    unit = "inch"
                elif any(u in line_upper for u in ["UM", "MICRON"]):
                    unit = "um"
                else:
                    unit = "mm"
                break
        info.native_unit = unit
        self.log("INFO", f"Detected native unit: {unit}")

        # 3. Parse Origin
        origin_x, origin_y = 0.0, 0.0
        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            if (line_upper.startswith("..ORIGIN") or line_upper.startswith(".ORIGIN") or
                line_upper.startswith("..BOARD_ORIGIN") or line_upper.startswith("..DESIGN_ORIGIN") or
                line_upper.startswith("..USER_ORIGIN") or line_upper.startswith("ORIGIN")):
                parts = re.findall(r"[-+]?\d*\.?\d+", line_clean)
                if len(parts) >= 2:
                    origin_x, origin_y = float(parts[0]), float(parts[1])
                    break
        info.board_origin_x = origin_x
        info.board_origin_y = origin_y

        # 4. Parse Layer Stack
        self.log("INFO", "Reading layer stack...")
        all_layers = []
        in_stackup_block = False
        layer_index = 1

        for line in lines:
            line_strip = line.strip()
            line_upper = line_strip.upper()

            if line_upper.startswith("..LAYER_STACKUP") or line_upper.startswith("..STACKUP") or line_upper.startswith(".STACK"):
                in_stackup_block = True
                continue
            elif in_stackup_block and line_upper.startswith(".."):
                in_stackup_block = False

            # Match .LAYER or conductor layer definitions
            if in_stackup_block or line_upper.startswith(".LAYER") or line_upper.startswith("..CONDUCTOR_LAYER") or line_upper.startswith(".CONDUCTOR"):
                # Handle quoted layer name
                m_quoted = re.search(r'\.LAYER\s+(?:\d+\s+)?["\']([^"\']+)["\'](?:\s+(.*))?', line_strip, re.IGNORECASE)
                if m_quoted:
                    name_candidate = m_quoted.group(1).strip()
                    type_candidate = (m_quoted.group(2) or "").strip()
                    layer_info = LayerDetector.classify_from_tokens(
                        name=name_candidate,
                        index=layer_index,
                        type_token=type_candidate
                    )
                    all_layers.append(layer_info)
                    layer_index += 1
                else:
                    parts = line_strip.split()
                    if len(parts) >= 2:
                        name_candidate = parts[1].strip('"\'')
                        type_candidate = " ".join(parts[2:]) if len(parts) > 2 else ""
                        if not name_candidate.startswith(".."):
                            layer_info = LayerDetector.classify_from_tokens(
                                name=name_candidate,
                                index=layer_index,
                                type_token=type_candidate
                            )
                            all_layers.append(layer_info)
                            layer_index += 1

        # Fallback to simple indexed layer lines if no stackup parsed
        if not all_layers:
            for line in lines:
                m = re.search(r"^\s*(\d+)\s*[\.:]?\s*([A-Za-z0-9_\-\s]+)", line)
                if m and not line.strip().upper().startswith(".."):
                    idx = int(m.group(1))
                    name = m.group(2).strip()
                    layer_info = LayerDetector.classify_from_tokens(name=name, index=idx)
                    all_layers.append(layer_info)

        info.all_layers = all_layers
        copper_layers = LayerDetector.filter_copper_layers(all_layers)
        info.total_copper_layers = len(copper_layers)
        info.copper_layer_names = [l.name for l in copper_layers]
        self.log("INFO", f"Copper layers detected: {info.total_copper_layers}")

        # 5. Parse Board Outline Geometry
        self.log("INFO", "Reading board outline...")
        points = []
        in_outline_block = False

        for line in lines:
            line_strip = line.strip()
            line_upper = line_strip.upper()

            if any(k in line_upper for k in ["..BOARD_OUTLINE", "..ROUTE_BORDER", "..BOARD_BORDER", "..OUTLINE", ".BORDER"]):
                in_outline_block = True
                continue
            elif in_outline_block and line_upper.startswith("..") and not any(k in line_upper for k in ["..PT", "..POLY", "..ARC", "..LINE"]):
                in_outline_block = False

            if in_outline_block:
                # Discard non-vertex directives inside outline block
                if any(line_upper.startswith(k) for k in [".LAYER", ".WIDTH", ".LINE_WIDTH", ".FILLET", ".TYPE", ".NET", ".CLEARANCE"]):
                    continue

                if line_upper.startswith(".PT") or line_upper.startswith("..PT") or line_upper.startswith(".XY") or line_upper.startswith("..XY") or line_upper.startswith(".POINT"):
                    coords = re.findall(r"[-+]?\d*\.?\d+", line_strip)
                    if len(coords) >= 2:
                        try:
                            points.append(Point(x=float(coords[0]), y=float(coords[1])))
                        except ValueError:
                            pass
                else:
                    # Check if line is purely two numbers (bare coordinate pair)
                    coords = re.findall(r"^[-+]?\d*\.?\d+\s+[-+]?\d*\.?\d+$", line_strip)
                    if coords:
                        parts = line_strip.split()
                        try:
                            points.append(Point(x=float(parts[0]), y=float(parts[1])))
                        except ValueError:
                            pass

        # Fallback vertex scan if outline block wasn't delimited
        if not points:
            for line in lines:
                line_clean = line.strip()
                line_u = line_clean.upper()
                if line_u.startswith(".PT") or line_u.startswith("..PT") or line_u.startswith(".XY"):
                    coords = re.findall(r"[-+]?\d*\.?\d+", line_clean)
                    if len(coords) >= 2:
                        points.append(Point(x=float(coords[0]), y=float(coords[1])))

        info.outline_points = points

        if points and OutlineDetector.validate_outline(points):
            info.board_outline_detected = True
            self.log("INFO", f"Board outline detected ({len(points)} vertices)")
            self.log("INFO", "Calculating bounding box...")
            bbox = OutlineDetector.calculate_bounding_box(points)
            if bbox:
                info.board_min_x = bbox.min_x
                info.board_max_x = bbox.max_x
                info.board_min_y = bbox.min_y
                info.board_max_y = bbox.max_y
                width, height, orientation = OutlineDetector.calculate_dimensions(bbox)
                info.board_width = width
                info.board_height = height
                info.orientation = orientation
                self.log("INFO", f"Board width: {width:.2f} {info.native_unit}")
                self.log("INFO", f"Board height: {height:.2f} {info.native_unit}")
                self.log("INFO", f"Orientation: {orientation}")
        else:
            info.board_outline_detected = False
            self.log("WARNING", "Board outline not detected.")
            info.calculate_dimensions()

        # If nothing could be recognized, fail validation
        if not all_layers and not points:
            return False

        return True

