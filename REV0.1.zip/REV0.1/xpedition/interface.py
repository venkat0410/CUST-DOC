"""
Abstract Base Interface for Xpedition PCB Readers.
Ensures loose coupling between the UI, extractor orchestrator, and backend reader engines.
"""

from abc import ABC, abstractmethod
from typing import Callable, Optional
from .models import PCBInfo


# Logging callback signature: log_callback(level: str, message: str)
LogCallback = Callable[[str, str], None]


class IPCBReader(ABC):
    """
    Abstract interface for PCB data extraction engines.
    Implementations must strictly observe the read-only requirement.
    """

    def __init__(self, log_cb: Optional[LogCallback] = None):
        self.log_cb = log_cb

    def log(self, level: str, message: str) -> None:
        """Emit a log message if a callback is registered."""
        if self.log_cb:
            self.log_cb(level, message)

    @abstractmethod
    def is_available(self) -> bool:
        """Check if this backend engine is available in the current environment."""
        pass

    @abstractmethod
    def read_pcb(self, file_path: str) -> PCBInfo:
        """
        Open the specified PCB, extract metadata, layers, and outline geometry,
        and safely close without modifying the original file.
        
        :param file_path: Absolute or relative path to the Xpedition PCB file.
        :return: PCBInfo data structure.
        """
        pass
