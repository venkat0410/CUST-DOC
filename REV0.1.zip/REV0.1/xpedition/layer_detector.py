"""
Copper Layer Detection and Layer Classification Engine.

Implements strict filtering rules to identify true conductor/copper layers
while rejecting user layers, documentation, mechanical, assembly, silkscreen,
dielectric, mask, and DXF layers.
"""

import re
from typing import List, Tuple
from .models import LayerInfo, LayerClass, ConductorSubtype
from .api_definitions import EPcbLayerType, EPcbLayerClass


# Non-copper keyword patterns for classification fallback
NON_COPPER_PATTERNS = [
    r"user.*layer",
    r"doc(umentation)?",
    r"mech(anical)?",
    r"assy|assembly",
    r"silk(screen)?",
    r"solder.*mask|soldermask|mask",
    r"paste.*mask|pastemask|paste",
    r"dxf",
    r"drill.*draw",
    r"fab(rication)?",
    r"keepout",
    r"cutout",
    r"dielectric|core|prepreg|fr4",
    r"title.*block",
    r"dimension",
    r"measure",
    r"temp(late)?",
]

# Copper layer pattern heuristics for fallback
COPPER_PATTERNS = [
    r"^top(\s+layer|\s+copper)?$",
    r"^bottom(\s+layer|\s+copper)?$",
    r"^inner\s*\d+",
    r"^in\s*\d+",
    r"^layer\s*\d+",
    r"^l\d+$",
    r"^sig(nal)?\s*\d*",
    r"^gnd|ground(\s*\d+)?",
    r"^pwr|power(\s*\d+)?",
    r"^vcc|vdd(\s*\d+)?",
    r"^plane\s*\d*",
    r"^conduct(or)?\s*\d*",
]


class LayerDetector:
    """
    Analyzes layer metadata and identifies genuine copper/conductor layers.
    """

    @staticmethod
    def classify_from_api(
        name: str,
        index: int,
        layer_type_code: int,
        layer_class_code: int = 0,
        raw_type_str: str = ""
    ) -> LayerInfo:
        """
        Classify layer using official Xpedition Layout API codes.
        
        :param name: Layer name string (e.g. 'TOP', 'GND', 'Silkscreen Top')
        :param index: Layer index
        :param layer_type_code: EPcbLayerType enum value
        :param layer_class_code: EPcbLayerClass enum value
        :param raw_type_str: String representation from API
        :return: LayerInfo object with is_copper flag and LayerClass.
        """
        is_copper = False
        layer_class = LayerClass.UNKNOWN
        subtype = None

        # 1. Primary check via EPcbLayerType
        if layer_type_code == EPcbLayerType.SIGNAL:
            is_copper = True
            layer_class = LayerClass.CONDUCTOR
            subtype = ConductorSubtype.SIGNAL
        elif layer_type_code == EPcbLayerType.PLANE:
            is_copper = True
            layer_class = LayerClass.CONDUCTOR
            subtype = ConductorSubtype.PLANE
        elif layer_type_code == EPcbLayerType.SPLIT_PLANE:
            is_copper = True
            layer_class = LayerClass.CONDUCTOR
            subtype = ConductorSubtype.SPLIT_PLANE
        elif layer_type_code == EPcbLayerType.MIXED:
            is_copper = True
            layer_class = LayerClass.CONDUCTOR
            subtype = ConductorSubtype.MIXED
        elif layer_type_code == EPcbLayerType.DIELECTRIC:
            is_copper = False
            layer_class = LayerClass.DIELECTRIC
        elif layer_type_code == EPcbLayerType.SOLDER_MASK:
            is_copper = False
            layer_class = LayerClass.SOLDER_MASK
        elif layer_type_code == EPcbLayerType.PASTE_MASK:
            is_copper = False
            layer_class = LayerClass.PASTE_MASK
        elif layer_type_code == EPcbLayerType.SILKSCREEN:
            is_copper = False
            layer_class = LayerClass.SILKSCREEN
        elif layer_type_code == EPcbLayerType.ASSEMBLY:
            is_copper = False
            layer_class = LayerClass.ASSEMBLY
        elif layer_type_code == EPcbLayerType.DOCUMENTATION:
            is_copper = False
            layer_class = LayerClass.DOCUMENTATION
        elif layer_type_code == EPcbLayerType.USER:
            is_copper = False
            layer_class = LayerClass.USER_LAYER
        elif layer_type_code == EPcbLayerType.MECHANICAL:
            is_copper = False
            layer_class = LayerClass.MECHANICAL
        elif layer_type_code == EPcbLayerType.DXF:
            is_copper = False
            layer_class = LayerClass.DXF_LAYER
        else:
            # 2. Secondary check via EPcbLayerClass if layer_type was generic or unknown
            if layer_class_code == EPcbLayerClass.CONDUCTOR:
                is_copper = True
                layer_class = LayerClass.CONDUCTOR
                subtype = ConductorSubtype.UNSPECIFIED
            elif layer_class_code == EPcbLayerClass.DIELECTRIC:
                is_copper = False
                layer_class = LayerClass.DIELECTRIC
            elif layer_class_code == EPcbLayerClass.NON_ELECTRICAL:
                is_copper = False
                layer_class = LayerClass.DOCUMENTATION
            else:
                # 3. Heuristic fallback based on name
                is_copper, layer_class, subtype = LayerDetector.classify_by_name(name)

        return LayerInfo(
            index=index,
            name=name,
            layer_class=layer_class,
            conductor_subtype=subtype,
            is_copper=is_copper,
            original_type_str=raw_type_str or str(layer_type_code)
        )

    @staticmethod
    def classify_from_tokens(
        name: str,
        index: int,
        type_token: str = "",
        class_token: str = ""
    ) -> LayerInfo:
        """
        Classify layer using explicit text tokens from Xpedition ASCII / HKP design file definitions.
        
        :param name: Layer name string
        :param index: Layer index
        :param type_token: String tokens (e.g. 'CONDUCTOR SIGNAL', 'MECHANICAL', 'DIELECTRIC')
        :param class_token: Optional class token (e.g. 'CONDUCTOR', 'NON_ELECTRICAL')
        :return: LayerInfo object with is_copper flag and LayerClass.
        """
        combined = f"{class_token} {type_token}".strip().upper()
        raw_str = combined if combined else name

        if combined:
            # 1. Check Conductor / Copper tokens
            if "CONDUCTOR" in combined or "SIGNAL" in combined or "PLANE" in combined or "SPLIT" in combined or "MIXED" in combined:
                # Ensure it's not a non-copper layer that happens to contain "signal" in notes
                if not any(k in combined for k in ["USER", "MECH", "SILK", "MASK", "ASSY", "DOC", "DXF"]):
                    st = ConductorSubtype.SIGNAL
                    if "PLANE" in combined or "SPLIT" in combined:
                        st = ConductorSubtype.SPLIT_PLANE if "SPLIT" in combined else ConductorSubtype.PLANE
                    elif "MIXED" in combined:
                        st = ConductorSubtype.MIXED
                    return LayerInfo(
                        index=index,
                        name=name,
                        layer_class=LayerClass.CONDUCTOR,
                        conductor_subtype=st,
                        is_copper=True,
                        original_type_str=raw_str
                    )

            # 2. Check Non-Copper tokens
            if any(k in combined for k in ["DIELECTRIC", "CORE", "PREPREG", "SUBSTRATE", "FR4"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.DIELECTRIC, is_copper=False, original_type_str=raw_str)
            if any(k in combined for k in ["SOLDERMASK", "SOLDER_MASK", "MASK"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.SOLDER_MASK, is_copper=False, original_type_str=raw_str)
            if any(k in combined for k in ["PASTEMASK", "PASTE_MASK", "PASTE"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.PASTE_MASK, is_copper=False, original_type_str=raw_str)
            if any(k in combined for k in ["SILKSCREEN", "SILK"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.SILKSCREEN, is_copper=False, original_type_str=raw_str)
            if any(k in combined for k in ["ASSEMBLY", "ASSY"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.ASSEMBLY, is_copper=False, original_type_str=raw_str)
            if any(k in combined for k in ["USER", "USER_LAYER"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.USER_LAYER, is_copper=False, original_type_str=raw_str)
            if any(k in combined for k in ["MECHANICAL", "MECH", "KEEPOUT", "CUTOUT"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.MECHANICAL, is_copper=False, original_type_str=raw_str)
            if any(k in combined for k in ["DXF"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.DXF_LAYER, is_copper=False, original_type_str=raw_str)
            if any(k in combined for k in ["DOCUMENTATION", "DOC", "FAB", "DRILL"]):
                return LayerInfo(index=index, name=name, layer_class=LayerClass.DOCUMENTATION, is_copper=False, original_type_str=raw_str)

        # 3. Fallback to name-based classification
        is_copper, lc, st = LayerDetector.classify_by_name(name)
        return LayerInfo(
            index=index,
            name=name,
            layer_class=lc,
            conductor_subtype=st,
            is_copper=is_copper,
            original_type_str=raw_str
        )

    @staticmethod
    def classify_by_name(name: str) -> Tuple[bool, LayerClass, Optional[ConductorSubtype]]:
        """
        Classify a layer by its textual name when API codes are unavailable.
        """
        clean_name = name.strip().lower()

        # Reject non-copper patterns first
        for pattern in NON_COPPER_PATTERNS:
            if re.search(pattern, clean_name):
                if "silk" in clean_name:
                    return False, LayerClass.SILKSCREEN, None
                if "mask" in clean_name:
                    return False, LayerClass.SOLDER_MASK, None
                if "paste" in clean_name:
                    return False, LayerClass.PASTE_MASK, None
                if "assy" in clean_name or "assembly" in clean_name:
                    return False, LayerClass.ASSEMBLY, None
                if "user" in clean_name:
                    return False, LayerClass.USER_LAYER, None
                if "mech" in clean_name or "cutout" in clean_name or "keepout" in clean_name:
                    return False, LayerClass.MECHANICAL, None
                if "dxf" in clean_name:
                    return False, LayerClass.DXF_LAYER, None
                if "dielectric" in clean_name or "core" in clean_name or "prepreg" in clean_name:
                    return False, LayerClass.DIELECTRIC, None
                return False, LayerClass.DOCUMENTATION, None

        # Check copper patterns
        for pattern in COPPER_PATTERNS:
            if re.search(pattern, clean_name):
                if "plane" in clean_name or "gnd" in clean_name or "pwr" in clean_name or "vcc" in clean_name:
                    return True, LayerClass.CONDUCTOR, ConductorSubtype.PLANE
                return True, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL

        # Unknown / default non-copper
        return False, LayerClass.UNKNOWN, None

    @staticmethod
    def filter_copper_layers(layers: List[LayerInfo]) -> List[LayerInfo]:
        """Filter and return only true copper/conductor layers."""
        return [l for l in layers if l.is_copper]

