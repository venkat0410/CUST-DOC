"""
Mock PCB Reader for Automated Testing and Offline Demonstration.

Provides verified reference datasets to test layer classification, bounding box
calculations, non-zero origins, orientation detection, and error scenarios.
"""

import os
from typing import Optional, Dict
from .interface import IPCBReader, LogCallback
from .models import PCBInfo, Point, LayerInfo, LayerClass, ConductorSubtype
from .layer_detector import LayerDetector
from .outline_detector import OutlineDetector


class MockXpeditionReader(IPCBReader):
    """
    Mock PCB reader simulating Siemens Xpedition Layout 2510 extraction.
    """

    def is_available(self) -> bool:
        return True

    def read_pcb(self, file_path: str) -> PCBInfo:
        abs_path = os.path.abspath(file_path)
        base_name = os.path.splitext(os.path.basename(file_path))[0]
        
        info = PCBInfo(
            pcb_name=base_name,
            file_path=abs_path,
            reader_backend="Xpedition Test Simulation Engine (Read-Only)",
            is_read_only=True
        )

        self.log("INFO", f"PCB selected: {abs_path}")
        self.log("INFO", "Opening PCB in Read-Only test mode...")

        # Select dataset based on file name or default to 6-layer landscape
        name_lower = base_name.lower()
        normalized = name_lower.replace("-", "_").replace(" ", "_")

        if "portrait" in normalized:
            self._apply_portrait_dataset(info)
        elif "square" in normalized:
            self._apply_square_dataset(info)
        elif "hex" in normalized or "complex" in normalized:
            self._apply_complex_polygon_dataset(info)
        elif "no_outline" in normalized or "missing_outline" in normalized:
            self._apply_missing_outline_dataset(info)
        else:
            self._apply_standard_6layer_dataset(info)

        info.extraction_successful = True
        self.log("INFO", "PCB closed without saving (Original PCB protected)")
        return info

    def _apply_standard_6layer_dataset(self, info: PCBInfo) -> None:
        """Standard 6-layer landscape board matching reference specification."""
        info.pcb_name = info.pcb_name or "DP-8001-TEST-V1"
        info.native_unit = "mm"
        info.board_origin_x = -10.25
        info.board_origin_y = 5.00

        self.log("INFO", "Reading layer stack...")
        raw_layers = [
            ("TOP", 1, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("SolderMask Top", 2, LayerClass.SOLDER_MASK, None, False),
            ("Silkscreen Top", 3, LayerClass.SILKSCREEN, None, False),
            ("Assembly Top", 4, LayerClass.ASSEMBLY, None, False),
            ("GND1", 5, LayerClass.CONDUCTOR, ConductorSubtype.PLANE, True),
            ("Core 1", 6, LayerClass.DIELECTRIC, None, False),
            ("PWR1", 7, LayerClass.CONDUCTOR, ConductorSubtype.PLANE, True),
            ("Prepreg 1", 8, LayerClass.DIELECTRIC, None, False),
            ("SIG1", 9, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("Core 2", 10, LayerClass.DIELECTRIC, None, False),
            ("SIG2", 11, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("Prepreg 2", 12, LayerClass.DIELECTRIC, None, False),
            ("BOTTOM", 13, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("SolderMask Bottom", 14, LayerClass.SOLDER_MASK, None, False),
            ("Silkscreen Bottom", 15, LayerClass.SILKSCREEN, None, False),
            ("User Layer Notes", 16, LayerClass.USER_LAYER, None, False),
            ("Mechanical Cutouts", 17, LayerClass.MECHANICAL, None, False),
            ("DXF Title Block", 18, LayerClass.DXF_LAYER, None, False),
            ("Drill Drawing", 19, LayerClass.DOCUMENTATION, None, False),
        ]

        info.all_layers = [
            LayerInfo(index=idx, name=name, layer_class=lc, conductor_subtype=st, is_copper=is_cop)
            for name, idx, lc, st, is_cop in raw_layers
        ]
        copper = LayerDetector.filter_copper_layers(info.all_layers)
        info.total_copper_layers = len(copper)
        info.copper_layer_names = [l.name for l in copper]
        self.log("INFO", f"Copper layers detected: {info.total_copper_layers}")

        self.log("INFO", "Reading board outline...")
        # Bounding box: X range -10.25 -> 110.25 (Width 120.50), Y range 5.00 -> 90.25 (Height 85.25)
        points = [
            Point(x=-10.25, y=5.00),
            Point(x=110.25, y=5.00),
            Point(x=110.25, y=90.25),
            Point(x=-10.25, y=90.25),
            Point(x=-10.25, y=5.00),
        ]
        info.outline_points = points
        info.board_outline_detected = True
        self.log("INFO", f"Board outline detected ({len(points)} vertices)")
        self.log("INFO", "Calculating bounding box...")

        bbox = OutlineDetector.calculate_bounding_box(points)
        if bbox:
            info.board_min_x = bbox.min_x
            info.board_max_x = bbox.max_x
            info.board_min_y = bbox.min_y
            info.board_max_y = bbox.max_y
            w, h, o = OutlineDetector.calculate_dimensions(bbox)
            info.board_width = w
            info.board_height = h
            info.orientation = o
            self.log("INFO", f"Board width: {w:.2f} {info.native_unit}")
            self.log("INFO", f"Board height: {h:.2f} {info.native_unit}")
            self.log("INFO", f"Orientation: {o}")

    def _apply_portrait_dataset(self, info: PCBInfo) -> None:
        """4-layer portrait board (75.00 x 140.00 mm)."""
        info.pcb_name = info.pcb_name or "DP-8002-PORTRAIT-V2"
        info.native_unit = "mm"
        info.board_origin_x = 0.00
        info.board_origin_y = 0.00

        self.log("INFO", "Reading layer stack...")
        raw_layers = [
            ("TOP", 1, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("INNER1_GND", 2, LayerClass.CONDUCTOR, ConductorSubtype.PLANE, True),
            ("INNER2_PWR", 3, LayerClass.CONDUCTOR, ConductorSubtype.PLANE, True),
            ("BOTTOM", 4, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("Silkscreen Top", 5, LayerClass.SILKSCREEN, None, False),
            ("Assembly Top", 6, LayerClass.ASSEMBLY, None, False),
        ]
        info.all_layers = [
            LayerInfo(index=idx, name=name, layer_class=lc, conductor_subtype=st, is_copper=is_cop)
            for name, idx, lc, st, is_cop in raw_layers
        ]
        copper = LayerDetector.filter_copper_layers(info.all_layers)
        info.total_copper_layers = len(copper)
        info.copper_layer_names = [l.name for l in copper]
        self.log("INFO", f"Copper layers detected: {info.total_copper_layers}")

        self.log("INFO", "Reading board outline...")
        points = [
            Point(x=0.00, y=0.00),
            Point(x=75.00, y=0.00),
            Point(x=75.00, y=140.00),
            Point(x=0.00, y=140.00),
            Point(x=0.00, y=0.00),
        ]
        info.outline_points = points
        info.board_outline_detected = True
        self.log("INFO", f"Board outline detected ({len(points)} vertices)")
        self.log("INFO", "Calculating bounding box...")

        bbox = OutlineDetector.calculate_bounding_box(points)
        if bbox:
            info.board_min_x = bbox.min_x
            info.board_max_x = bbox.max_x
            info.board_min_y = bbox.min_y
            info.board_max_y = bbox.max_y
            w, h, o = OutlineDetector.calculate_dimensions(bbox)
            info.board_width = w
            info.board_height = h
            info.orientation = o
            self.log("INFO", f"Board width: {w:.2f} {info.native_unit}")
            self.log("INFO", f"Board height: {h:.2f} {info.native_unit}")
            self.log("INFO", f"Orientation: {o}")

    def _apply_square_dataset(self, info: PCBInfo) -> None:
        """2-layer square board (100.00 x 100.00 mm) in mils."""
        info.pcb_name = info.pcb_name or "DP-8003-SQUARE-V1"
        info.native_unit = "mil"
        info.board_origin_x = 500.0
        info.board_origin_y = 500.0

        self.log("INFO", "Reading layer stack...")
        raw_layers = [
            ("TOP", 1, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("BOTTOM", 2, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("Solder Mask", 3, LayerClass.SOLDER_MASK, None, False),
        ]
        info.all_layers = [
            LayerInfo(index=idx, name=name, layer_class=lc, conductor_subtype=st, is_copper=is_cop)
            for name, idx, lc, st, is_cop in raw_layers
        ]
        copper = LayerDetector.filter_copper_layers(info.all_layers)
        info.total_copper_layers = len(copper)
        info.copper_layer_names = [l.name for l in copper]
        self.log("INFO", f"Copper layers detected: {info.total_copper_layers}")

        self.log("INFO", "Reading board outline...")
        points = [
            Point(x=500.0, y=500.0),
            Point(x=4500.0, y=500.0),
            Point(x=4500.0, y=4500.0),
            Point(x=500.0, y=4500.0),
            Point(x=500.0, y=500.0),
        ]
        info.outline_points = points
        info.board_outline_detected = True
        self.log("INFO", f"Board outline detected ({len(points)} vertices)")
        self.log("INFO", "Calculating bounding box...")

        bbox = OutlineDetector.calculate_bounding_box(points)
        if bbox:
            info.board_min_x = bbox.min_x
            info.board_max_x = bbox.max_x
            info.board_min_y = bbox.min_y
            info.board_max_y = bbox.max_y
            w, h, o = OutlineDetector.calculate_dimensions(bbox)
            info.board_width = w
            info.board_height = h
            info.orientation = o
            self.log("INFO", f"Board width: {w:.2f} {info.native_unit}")
            self.log("INFO", f"Board height: {h:.2f} {info.native_unit}")
            self.log("INFO", f"Orientation: {o}")

    def _apply_complex_polygon_dataset(self, info: PCBInfo) -> None:
        """Complex polygon (hexagon with cutouts) board."""
        info.pcb_name = info.pcb_name or "DP-8004-HEXAGON-V1"
        info.native_unit = "mm"
        info.board_origin_x = -25.0
        info.board_origin_y = -15.0

        self.log("INFO", "Reading layer stack...")
        raw_layers = [
            ("TOP", 1, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("IN1", 2, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("IN2_GND", 3, LayerClass.CONDUCTOR, ConductorSubtype.PLANE, True),
            ("IN3_PWR", 4, LayerClass.CONDUCTOR, ConductorSubtype.PLANE, True),
            ("IN4_SIG", 5, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("IN5_SIG", 6, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("IN6_GND", 7, LayerClass.CONDUCTOR, ConductorSubtype.PLANE, True),
            ("BOTTOM", 8, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
        ]
        info.all_layers = [
            LayerInfo(index=idx, name=name, layer_class=lc, conductor_subtype=st, is_copper=is_cop)
            for name, idx, lc, st, is_cop in raw_layers
        ]
        copper = LayerDetector.filter_copper_layers(info.all_layers)
        info.total_copper_layers = len(copper)
        info.copper_layer_names = [l.name for l in copper]
        self.log("INFO", f"Copper layers detected: {info.total_copper_layers}")

        self.log("INFO", "Reading board outline...")
        # 6-sided polygon vertices spanning X: -25.0 -> 125.0 (width 150), Y: -15.0 -> 95.0 (height 110)
        points = [
            Point(x=0.0, y=-15.0),
            Point(x=100.0, y=-15.0),
            Point(x=125.0, y=40.0),
            Point(x=100.0, y=95.0),
            Point(x=0.0, y=95.0),
            Point(x=-25.0, y=40.0),
            Point(x=0.0, y=-15.0),
        ]
        info.outline_points = points
        info.board_outline_detected = True
        self.log("INFO", f"Board outline detected ({len(points)} vertices)")
        self.log("INFO", "Calculating bounding box...")

        bbox = OutlineDetector.calculate_bounding_box(points)
        if bbox:
            info.board_min_x = bbox.min_x
            info.board_max_x = bbox.max_x
            info.board_min_y = bbox.min_y
            info.board_max_y = bbox.max_y
            w, h, o = OutlineDetector.calculate_dimensions(bbox)
            info.board_width = w
            info.board_height = h
            info.orientation = o
            self.log("INFO", f"Board width: {w:.2f} {info.native_unit}")
            self.log("INFO", f"Board height: {h:.2f} {info.native_unit}")
            self.log("INFO", f"Orientation: {o}")

    def _apply_missing_outline_dataset(self, info: PCBInfo) -> None:
        """Simulate a design without a board outline."""
        info.pcb_name = info.pcb_name or "DP-8005-NO-OUTLINE"
        info.native_unit = "mm"
        info.board_origin_x = 0.0
        info.board_origin_y = 0.0

        self.log("INFO", "Reading layer stack...")
        raw_layers = [
            ("TOP", 1, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
            ("BOTTOM", 2, LayerClass.CONDUCTOR, ConductorSubtype.SIGNAL, True),
        ]
        info.all_layers = [
            LayerInfo(index=idx, name=name, layer_class=lc, conductor_subtype=st, is_copper=is_cop)
            for name, idx, lc, st, is_cop in raw_layers
        ]
        copper = LayerDetector.filter_copper_layers(info.all_layers)
        info.total_copper_layers = len(copper)
        info.copper_layer_names = [l.name for l in copper]
        self.log("INFO", f"Copper layers detected: {info.total_copper_layers}")

        self.log("INFO", "Reading board outline...")
        self.log("WARNING", "Board outline not detected in design database.")
        info.board_outline_detected = False
        info.calculate_dimensions()
