"""
Data models for PCB representation, geometric primitives, and layer classifications.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple


class LayerClass(Enum):
    """Classification of PCB layers according to Siemens Xpedition specifications."""
    CONDUCTOR = "Conductor"          # Signal, Plane, Split Plane, Mixed -> COPPER
    DIELECTRIC = "Dielectric"        # Prepreg, Core -> NON-COPPER
    SOLDER_MASK = "Solder Mask"      # Solder Mask Top/Bottom -> NON-COPPER
    PASTE_MASK = "Paste Mask"        # Paste Mask Top/Bottom -> NON-COPPER
    SILKSCREEN = "Silkscreen"        # Silkscreen Top/Bottom -> NON-COPPER
    ASSEMBLY = "Assembly"            # Assembly Top/Bottom -> NON-COPPER
    DOCUMENTATION = "Documentation"  # Drill drawing, Fab notes -> NON-COPPER
    MECHANICAL = "Mechanical"        # Cutouts, Keepouts, Stiffeners -> NON-COPPER
    USER_LAYER = "User Layer"        # Custom user layers -> NON-COPPER
    DXF_LAYER = "DXF Layer"          # Imported DXF geometry -> NON-COPPER
    UNKNOWN = "Unknown"


class ConductorSubtype(Enum):
    """Conductor layer electrical types."""
    SIGNAL = "Signal"
    PLANE = "Plane"
    SPLIT_PLANE = "Split Plane"
    MIXED = "Mixed"
    UNSPECIFIED = "Conductor"


@dataclass
class Point:
    """2D Geometric point in PCB coordinate space."""
    x: float
    y: float

    def __iter__(self):
        yield self.x
        yield self.y

    def as_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)


@dataclass
class BoundingBox:
    """Bounding box calculated from actual PCB geometry."""
    min_x: float
    max_x: float
    min_y: float
    max_y: float

    @property
    def width(self) -> float:
        """Board Width = Xmax - Xmin."""
        return self.max_x - self.min_x

    @property
    def height(self) -> float:
        """Board Height = Ymax - Ymin."""
        return self.max_y - self.min_y

    @property
    def orientation(self) -> str:
        """
        Determine orientation based on dimensions:
        If Width > Height: Landscape
        If Height > Width: Portrait
        If Width == Height: Square
        """
        w = round(self.width, 4)
        h = round(self.height, 4)
        if w <= 0 or h <= 0:
            return "Unknown"
        if w > h:
            return "Landscape"
        elif h > w:
            return "Portrait"
        else:
            return "Square"



@dataclass
class LayerInfo:
    """Detailed layer metadata."""
    index: int
    name: str
    layer_class: LayerClass
    conductor_subtype: Optional[ConductorSubtype] = None
    is_copper: bool = False
    original_type_str: str = ""


@dataclass
class PCBInfo:
    """
    Extracted PCB Information container.
    Guarantees consistent data representation across all reader engines.
    """
    pcb_name: str
    file_path: str
    native_unit: str = "mm"
    
    # Layer stack information
    total_copper_layers: int = 0
    copper_layer_names: List[str] = field(default_factory=list)
    all_layers: List[LayerInfo] = field(default_factory=list)
    
    # Board outline & geometry
    board_outline_detected: bool = False
    board_origin_x: float = 0.0
    board_origin_y: float = 0.0
    board_min_x: float = 0.0
    board_max_x: float = 0.0
    board_min_y: float = 0.0
    board_max_y: float = 0.0
    board_width: float = 0.0
    board_height: float = 0.0
    orientation: str = "Unknown"
    
    # Raw outline geometry vertices
    outline_points: List[Point] = field(default_factory=list)
    
    # Engine & execution metadata
    reader_backend: str = "Unknown"
    is_read_only: bool = True
    extraction_successful: bool = False
    error_message: Optional[str] = None

    def calculate_dimensions(self) -> None:
        """Calculate width, height, and orientation from bounding box coordinates."""
        if self.board_outline_detected:
            self.board_width = round(self.board_max_x - self.board_min_x, 4)
            self.board_height = round(self.board_max_y - self.board_min_y, 4)
            if self.board_width > self.board_height:
                self.orientation = "Landscape"
            elif self.board_height > self.board_width:
                self.orientation = "Portrait"
            else:
                self.orientation = "Square"
        else:
            self.board_width = 0.0
            self.board_height = 0.0
            self.orientation = "Unknown"

    def format_summary(self) -> str:
        """Format human-readable summary matching the task specification."""
        lines = [
            "--------------------------------------------------",
            "PCB INFORMATION",
            "--------------------------------------------------",
            f"PCB Name:       {self.pcb_name}",
            f"PCB File:       {self.file_path}",
            f"Native Unit:    {self.native_unit}",
            f"Copper Layers:  {self.total_copper_layers}",
        ]
        
        if self.copper_layer_names:
            lines.append("Layer Stack:")
            for idx, name in enumerate(self.copper_layer_names, start=1):
                lines.append(f"  {idx}. {name}")
                
        if self.board_outline_detected:
            lines.extend([
                f"Board Outline:  Detected ({len(self.outline_points)} vertices)",
                f"Board Width:    {self.board_width:.2f} {self.native_unit}",
                f"Board Height:   {self.board_height:.2f} {self.native_unit}",
                f"Board Origin:   X = {self.board_origin_x:.2f} {self.native_unit}, Y = {self.board_origin_y:.2f} {self.native_unit}",
                f"X Range:        {self.board_min_x:.2f} -> {self.board_max_x:.2f} {self.native_unit}",
                f"Y Range:        {self.board_min_y:.2f} -> {self.board_max_y:.2f} {self.native_unit}",
                f"Orientation:    {self.orientation}",
            ])
        else:
            lines.append("Board Outline:  Not Detected")
            
        lines.append(f"Backend Engine: {self.reader_backend}")
        lines.append(f"PCB Protected:  {'Yes (Read-Only)' if self.is_read_only else 'No'}")
        lines.append("--------------------------------------------------")
        return "\n".join(lines)
