"""
Board Outline Detection, Bounding Box, and Dimension Calculation Engine.

Calculates exact bounding box, dimensions, and orientation from PCB geometry
points without assuming (0,0) origin or simple rectangular shapes.
"""

from typing import List, Optional, Tuple
from .models import Point, BoundingBox


class OutlineDetector:
    """
    Processes board outline vertices, computing bounding coordinates, dimensions,
    and orientation while preserving true coordinate systems.
    """

    @staticmethod
    def calculate_bounding_box(points: List[Point]) -> Optional[BoundingBox]:
        """
        Calculate bounding box from a list of 2D geometry vertices.
        Handles arbitrary polygons, negative coordinates, and offsets.
        
        :param points: List of Point objects representing the board outline.
        :return: BoundingBox or None if points list is empty.
        """
        if not points:
            return None

        xs = [p.x for p in points]
        ys = [p.y for p in points]

        min_x = min(xs)
        max_x = max(xs)
        min_y = min(ys)
        max_y = max(ys)

        return BoundingBox(
            min_x=round(min_x, 4),
            max_x=round(max_x, 4),
            min_y=round(min_y, 4),
            max_y=round(max_y, 4)
        )

    @staticmethod
    def calculate_dimensions(bbox: BoundingBox) -> Tuple[float, float, str]:
        """
        Calculate board width, height, and orientation from a BoundingBox.
        
        Formula:
        Board Width  = Xmax - Xmin
        Board Height = Ymax - Ymin
        
        Orientation:
        If Width > Height: Landscape
        If Height > Width: Portrait
        If Width == Height: Square
        
        :return: (width, height, orientation)
        """
        width = round(bbox.width, 4)
        height = round(bbox.height, 4)
        orientation = bbox.orientation
        return width, height, orientation

    @staticmethod
    def validate_outline(points: List[Point]) -> bool:
        """
        Validate that the outline points form a valid closed or non-degenerate shape.
        At least 3 distinct non-collinear vertices are required for a physical board.
        """
        if len(points) < 3:
            return False

        xs = set(round(p.x, 4) for p in points)
        ys = set(round(p.y, 4) for p in points)

        # Non-degenerate check: must span both X and Y dimensions
        if len(xs) < 2 or len(ys) < 2:
            return False

        bbox = OutlineDetector.calculate_bounding_box(points)
        if bbox is None or bbox.width <= 0 or bbox.height <= 0:
            return False

        return True
