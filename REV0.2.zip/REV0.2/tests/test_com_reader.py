"""
Unit tests for Siemens Xpedition COM Reader interface and multi-ProgID probing.
"""

import os
import unittest
from unittest.mock import patch, MagicMock
from xpedition.com_reader import XpeditionCOMReader
from xpedition.api_definitions import (
    PROGIDS_XPEDITION,
    COM_ERR_NOT_INSTALLED,
    COM_ERR_DOCUMENT_LOCKED,
    COM_ERR_LICENSE_REQUIRED,
    COM_ERR_DOCUMENT_OPEN_FAILED,
)


class TestCOMReader(unittest.TestCase):

    def setUp(self):
        self.reader = XpeditionCOMReader()

    def test_progid_list_defined(self):
        """Verify multi-ProgID candidate list contains official Siemens/Mentor interfaces."""
        self.assertIn("MGCPCB.ExpeditionPCBApplication", PROGIDS_XPEDITION)
        self.assertIn("MGCPCBAutomation.ExpeditionPCBApplication", PROGIDS_XPEDITION)
        self.assertIn("MGCPCB.Application", PROGIDS_XPEDITION)
        self.assertIn("XpeditionPCB.Application", PROGIDS_XPEDITION)

    def test_com_status_description(self):
        """Verify status description string reflects current environment."""
        desc = self.reader.get_status_description()
        self.assertIsInstance(desc, str)
        if self.reader.is_available():
            self.assertIn("COM Ready", desc)
        else:
            self.assertIn("COM Offline", desc)

    def test_com_reader_non_existent_file(self):
        """Verify non-existent file handling in COM reader."""
        info = self.reader.read_pcb(r"E:\Creative\PCB\does_not_exist_com.pcb")
        self.assertFalse(info.extraction_successful)
        self.assertIn("Unable to read PCB file", info.error_message)

    @patch.object(XpeditionCOMReader, "_execute_com_extraction")
    def test_com_reader_simulated_success(self, mock_exec):
        """Test parsing valid COM automation data payload."""
        mock_exec.return_value = (
            True,
            {
                "status": "success",
                "name": "TEST_COM_DESIGN",
                "unit": "mm",
                "origin_x": -10.0,
                "origin_y": 5.0,
                "layers": [
                    {"index": 1, "name": "TOP", "type": 1, "class": 1},
                    {"index": 2, "name": "GND1", "type": 2, "class": 1},
                    {"index": 3, "name": "PWR1", "type": 2, "class": 1},
                    {"index": 4, "name": "BOTTOM", "type": 1, "class": 1},
                    {"index": 5, "name": "SolderMask Top", "type": 6, "class": 3},
                ],
                "outline_points": [
                    {"x": -10.0, "y": 5.0},
                    {"x": 90.0, "y": 5.0},
                    {"x": 90.0, "y": 65.0},
                    {"x": -10.0, "y": 65.0},
                    {"x": -10.0, "y": 5.0},
                ],
                "progid": "MGCPCB.ExpeditionPCBApplication"
            },
            ""
        )
        # Create a dummy file so exists() passes
        sample_path = os.path.join(os.path.dirname(__file__), "sample_designs", "2layer_square.hkp")
        info = self.reader.read_pcb(sample_path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.pcb_name, "TEST_COM_DESIGN")
        self.assertEqual(info.total_copper_layers, 4)
        self.assertEqual(info.copper_layer_names, ["TOP", "GND1", "PWR1", "BOTTOM"])
        self.assertTrue(info.board_outline_detected)
        self.assertAlmostEqual(info.board_width, 100.0, places=2)
        self.assertAlmostEqual(info.board_height, 60.0, places=2)
        self.assertEqual(info.orientation, "Landscape")

    @patch.object(XpeditionCOMReader, "_execute_com_extraction")
    def test_com_reader_categorized_errors(self, mock_exec):
        """Test COM error categorization for not installed, locked, and license required."""
        sample_path = os.path.join(os.path.dirname(__file__), "sample_designs", "2layer_square.hkp")

        # Case 1: License required
        mock_exec.return_value = (False, {}, "Siemens Xpedition license not found or license server unavailable.")
        info = self.reader.read_pcb(sample_path)
        self.assertFalse(info.extraction_successful)
        self.assertIn("license", info.error_message.lower())

        # Case 2: Document locked
        mock_exec.return_value = (False, {}, "PCB file is locked or currently open exclusively by another process.")
        info = self.reader.read_pcb(sample_path)
        self.assertFalse(info.extraction_successful)
        self.assertIn("locked", info.error_message.lower())


if __name__ == "__main__":
    unittest.main()
