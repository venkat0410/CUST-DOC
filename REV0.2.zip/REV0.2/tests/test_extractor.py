"""
Integration tests for the PCBInformationExtractor orchestrator.
Tests routing across COM, Direct File Parser (HKP/Gerber/Binary), and Mock Simulation engines.
"""

import os
import unittest
from xpedition import PCBInformationExtractor

SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "sample_designs")


class TestExtractorOrchestrator(unittest.TestCase):

    def setUp(self):
        self.extractor = PCBInformationExtractor()

    def test_auto_mode_real_hkp_layout(self):
        """Test Auto Mode routing to direct parser on real HKP layout file."""
        path = os.path.join(SAMPLE_DIR, "real_layout_polyarc.hkp")
        info = self.extractor.extract(path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 6)
        self.assertEqual(info.copper_layer_names, ["TOP", "GND1", "PWR1", "SIG1", "SIG2", "BOTTOM"])
        self.assertTrue(info.board_outline_detected)
        self.assertAlmostEqual(info.board_width, 120.50, places=2)
        self.assertAlmostEqual(info.board_height, 85.25, places=2)
        self.assertEqual(info.orientation, "Landscape")
        self.assertTrue(info.is_read_only)

    def test_auto_mode_gerber_outline(self):
        """Test Auto Mode routing to Gerber outline parser."""
        path = os.path.join(SAMPLE_DIR, "sample_outline.gko")
        info = self.extractor.extract(path)
        self.assertTrue(info.extraction_successful)
        self.assertTrue(info.board_outline_detected)
        self.assertAlmostEqual(info.board_width, 100.00, places=2)
        self.assertAlmostEqual(info.board_height, 60.00, places=2)
        self.assertEqual(info.orientation, "Landscape")

    def test_auto_mode_binary_stream_inspection(self):
        """Test Auto Mode inspecting binary PCB with embedded strings."""
        path = os.path.join(SAMPLE_DIR, "sample_binary_with_strings.pcb")
        info = self.extractor.extract(path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 4)
        self.assertFalse(info.board_outline_detected)
        self.assertIn("For full vector geometry & outline bounding box", info.error_message)

    def test_forced_direct_backend(self):
        """Test forcing Direct File parser backend explicitly."""
        extractor = PCBInformationExtractor(force_backend="direct")
        path = os.path.join(SAMPLE_DIR, "6layer_landscape.hkp")
        info = extractor.extract(path)
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 6)
        self.assertIn("Direct File Parser", info.reader_backend)

    def test_forced_mock_backend(self):
        """Test forcing Mock Simulation engine explicitly."""
        extractor = PCBInformationExtractor(force_backend="mock")
        info = extractor.extract("DP-8001-TEST-V1.pcb")
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 6)
        self.assertIn("Test Simulation Engine", info.reader_backend)

    def test_mock_backend_standard_6layer(self):
        info = self.extractor.mock_reader.read_pcb("DP-8001-TEST-V1.pcb")
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 6)
        self.assertEqual(info.copper_layer_names, ["TOP", "GND1", "PWR1", "SIG1", "SIG2", "BOTTOM"])
        self.assertTrue(info.board_outline_detected)
        self.assertAlmostEqual(info.board_width, 120.50, places=2)
        self.assertAlmostEqual(info.board_height, 85.25, places=2)
        self.assertAlmostEqual(info.board_origin_x, -10.25, places=2)
        self.assertAlmostEqual(info.board_origin_y, 5.00, places=2)
        self.assertEqual(info.orientation, "Landscape")

    def test_mock_backend_portrait(self):
        info = self.extractor.mock_reader.read_pcb("DP-8002-PORTRAIT-V2.pcb")
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 4)
        self.assertEqual(info.orientation, "Portrait")
        self.assertAlmostEqual(info.board_width, 75.00, places=2)
        self.assertAlmostEqual(info.board_height, 140.00, places=2)

    def test_mock_backend_square(self):
        info = self.extractor.mock_reader.read_pcb("DP-8003-SQUARE-V1.pcb")
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 2)
        self.assertEqual(info.orientation, "Square")
        self.assertEqual(info.native_unit, "mil")

    def test_mock_backend_complex_polygon(self):
        info = self.extractor.mock_reader.read_pcb("DP-8004-HEXAGON-V1.pcb")
        self.assertTrue(info.extraction_successful)
        self.assertEqual(info.total_copper_layers, 8)
        self.assertEqual(info.orientation, "Landscape")
        self.assertAlmostEqual(info.board_width, 150.00, places=2)
        self.assertAlmostEqual(info.board_height, 110.00, places=2)

    def test_mock_backend_no_outline(self):
        info = self.extractor.mock_reader.read_pcb("DP-8005-MISSING-OUTLINE.pcb")
        self.assertTrue(info.extraction_successful)
        self.assertFalse(info.board_outline_detected)
        self.assertEqual(info.orientation, "Unknown")
        self.assertEqual(info.board_width, 0.0)
        self.assertEqual(info.board_height, 0.0)

    def test_empty_file_input(self):
        info = self.extractor.extract("")
        self.assertFalse(info.extraction_successful)
        self.assertIn("No file path provided", info.error_message)

    def test_invalid_format_rejection(self):
        invalid_path = os.path.join(SAMPLE_DIR, "invalid_format.txt")
        info = self.extractor.extract(invalid_path)
        self.assertFalse(info.extraction_successful)
        self.assertIn("Unable to read PCB file", info.error_message)

    def test_non_existent_file(self):
        info = self.extractor.extract(r"E:\Creative\PCB\does_not_exist_xyz.pcb")
        self.assertFalse(info.extraction_successful)
        self.assertIn("Unable to read PCB file", info.error_message)

    def test_binary_file_fallback_error(self):
        # Create temporary dummy binary file with no metadata
        bin_path = os.path.join(SAMPLE_DIR, "temp_binary.pcb")
        with open(bin_path, "wb") as bf:
            bf.write(b"\x00\x01\x02\x03\x04MGCPCB_BINARY_DATABASE_SAMPLE\x00\x00")
        try:
            info = self.extractor.extract(bin_path)
            self.assertFalse(info.extraction_successful)
            self.assertIn("PCB format or Xpedition API interface could not be accessed", info.error_message)
        finally:
            if os.path.exists(bin_path):
                os.remove(bin_path)


if __name__ == "__main__":
    unittest.main()
