"""
Main Window for Siemens Xpedition Layout PCB Reader & Information Extraction.
"""

import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Optional

from config import (
    APP_NAME,
    APP_SUBTITLE,
    APP_VERSION,
    XPEDITION_FILE_EXTENSIONS,
    ORIENTATION_LANDSCAPE,
    ORIENTATION_PORTRAIT,
    ORIENTATION_SQUARE,
    OUTLINE_DETECTED,
    OUTLINE_NOT_DETECTED,
)
from xpedition import (
    PCBInformationExtractor,
    PCBInfo,
    API_INVESTIGATION_MATRIX,
)
from .theme import (
    COLOR_BG,
    COLOR_CARD_BG,
    COLOR_CARD_BORDER,
    COLOR_HEADER_BG,
    COLOR_HEADER_FG,
    COLOR_HEADER_SUB,
    COLOR_PRIMARY,
    COLOR_PRIMARY_HOVER,
    COLOR_PRIMARY_FG,
    COLOR_SECONDARY,
    COLOR_SECONDARY_HOVER,
    COLOR_SECONDARY_FG,
    COLOR_TEXT_MAIN,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_LABEL,
    FONT_HEADER,
    FONT_SUBHEADER,
    FONT_SECTION_TITLE,
    FONT_BODY,
    FONT_BODY_BOLD,
    FONT_LABEL,
    FONT_VALUE,
    FONT_VALUE_EMPHASIS,
)
from .components import CardFrame, InfoField, StatusBadge, ConsoleLogViewer


class MainWindow(tk.Tk):
    """
    Main Application Window for Step 1 PCB Reader.
    """

    def __init__(self):
        super().__init__()

        self.title(f"{APP_NAME} (v{APP_VERSION})")
        self.geometry("980x880")
        self.minsize(880, 720)
        self.configure(bg=COLOR_BG)

        # Extraction state
        self.selected_file_path: Optional[str] = None
        self.current_pcb_info: Optional[PCBInfo] = None

        # Extractor orchestrator
        self.extractor = PCBInformationExtractor(log_cb=self._log_callback)

        # Build UI layout
        self._create_header()
        self._create_main_container()
        self._create_status_bar()

        # Initial log
        self.log_viewer.log("INFO", f"{APP_NAME} initialized.")
        self.log_viewer.log("INFO", "Ready. Please select an Xpedition PCB file to read.")

    def _log_callback(self, level: str, message: str) -> None:
        """Callback to pipe extractor logs directly to the live console."""
        if hasattr(self, "log_viewer"):
            self.log_viewer.log(level, message)
            self.update_idletasks()

    def _create_header(self) -> None:
        """Top branding header banner."""
        header_frame = tk.Frame(self, bg=COLOR_HEADER_BG, padx=20, pady=12)
        header_frame.pack(fill="x")

        title_box = tk.Frame(header_frame, bg=COLOR_HEADER_BG)
        title_box.pack(side="left", fill="y")

        title_lbl = tk.Label(
            title_box,
            text=APP_NAME,
            font=FONT_HEADER,
            bg=COLOR_HEADER_BG,
            fg=COLOR_HEADER_FG
        )
        title_lbl.pack(anchor="w")

        sub_lbl = tk.Label(
            title_box,
            text=APP_SUBTITLE,
            font=FONT_SUBHEADER,
            bg=COLOR_HEADER_BG,
            fg=COLOR_HEADER_SUB
        )
        sub_lbl.pack(anchor="w", pady=(2, 0))

        # Right-side status badges
        badge_box = tk.Frame(header_frame, bg=COLOR_HEADER_BG)
        badge_box.pack(side="right", fill="y")

        protect_badge = StatusBadge(badge_box, text="ORIGINAL PCB PROTECTED (READ-ONLY)", status_type="success")
        protect_badge.pack(anchor="e", pady=2)

        com_avail = self.extractor.com_reader.is_available()
        com_text = "COM AUTOMATION: READY" if com_avail else "COM: OFFLINE (DIRECT ACTIVE)"
        com_type = "success" if com_avail else "neutral"
        self.com_badge = StatusBadge(badge_box, text=com_text, status_type=com_type)
        self.com_badge.pack(anchor="e", pady=2)


    def _create_main_container(self) -> None:
        """Main scrollable/responsive content container."""
        # Scrollable canvas container for smaller screens
        container = tk.Frame(self, bg=COLOR_BG)
        container.pack(fill="both", expand=True, padx=16, pady=12)

        # Top Section: File Selector Card
        self._create_selector_card(container)

        # Middle Section: Information Grid (2 columns: Specs & Outline on left, Layers on right)
        info_grid = tk.Frame(container, bg=COLOR_BG)
        info_grid.pack(fill="both", expand=False, pady=(10, 0))
        info_grid.columnconfigure(0, weight=3)
        info_grid.columnconfigure(1, weight=2)

        self._create_dimensions_card(info_grid)
        self._create_layers_card(info_grid)

        # Bottom Section: Debug & Automation Log Viewer Card
        log_card = CardFrame(container, title="Automation & Extraction Log")
        log_card.pack(fill="both", expand=True, pady=(10, 0))

        self.log_viewer = ConsoleLogViewer(log_card)
        self.log_viewer.pack(fill="both", expand=True)

    def _create_selector_card(self, parent: tk.Frame) -> None:
        """Card for file browsing, path display, backend selection, and execution."""
        card = CardFrame(parent, title="PCB File Selection")
        card.pack(fill="x")

        # Top row: File path entry and Browse button
        file_row = tk.Frame(card, bg=COLOR_CARD_BG)
        file_row.pack(fill="x", pady=(0, 8))

        browse_btn = tk.Button(
            file_row,
            text="📁 Select PCB File",
            font=FONT_BODY_BOLD,
            bg=COLOR_PRIMARY,
            fg=COLOR_PRIMARY_FG,
            activebackground=COLOR_PRIMARY_HOVER,
            activeforeground=COLOR_PRIMARY_FG,
            bd=0,
            padx=14,
            pady=6,
            cursor="hand2",
            command=self._on_select_file
        )
        browse_btn.pack(side="left")

        self.file_path_var = tk.StringVar(value="No PCB file selected.")
        path_entry = tk.Entry(
            file_row,
            textvariable=self.file_path_var,
            font=FONT_VALUE,
            fg=COLOR_TEXT_MAIN,
            bg="#f1f5f9",
            bd=1,
            relief="solid",
            state="readonly"
        )
        path_entry.pack(side="left", fill="x", expand=True, padx=(10, 0), ipady=4)

        # Bottom row: PCB Name, Backend Mode Selector, and Read PCB action button
        action_row = tk.Frame(card, bg=COLOR_CARD_BG)
        action_row.pack(fill="x", pady=(6, 0))

        # PCB Name display
        name_frame = tk.Frame(action_row, bg=COLOR_CARD_BG)
        name_frame.pack(side="left", fill="x", expand=True)

        name_lbl = tk.Label(name_frame, text="PCB / Design Name:", font=FONT_LABEL, fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_BG)
        name_lbl.pack(side="left")

        self.pcb_name_var = tk.StringVar(value="-")
        name_val = tk.Label(name_frame, textvariable=self.pcb_name_var, font=FONT_VALUE_EMPHASIS, fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_BG)
        name_val.pack(side="left", padx=(6, 0))

        # Backend Engine Selector
        backend_frame = tk.Frame(action_row, bg=COLOR_CARD_BG)
        backend_frame.pack(side="left", padx=16)

        be_lbl = tk.Label(backend_frame, text="Engine:", font=FONT_LABEL, fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_BG)
        be_lbl.pack(side="left", padx=(0, 4))

        self.backend_var = tk.StringVar(value="Auto (COM / Fallback)")
        backend_combo = ttk.Combobox(
            backend_frame,
            textvariable=self.backend_var,
            values=[
                "Auto (COM / Fallback)",
                "Direct File Parser (HKP / Gerber)",
                "Siemens Xpedition COM (Live)",
                "Xpedition Test Simulation Engine"
            ],
            state="readonly",
            width=32
        )
        backend_combo.pack(side="left")

        # Read PCB Button
        self.read_btn = tk.Button(
            action_row,
            text="⚡ Read PCB",
            font=FONT_BODY_BOLD,
            bg="#16a34a",
            fg="#ffffff",
            activebackground="#15803d",
            activeforeground="#ffffff",
            bd=0,
            padx=20,
            pady=6,
            cursor="hand2",
            command=self._on_read_pcb
        )
        self.read_btn.pack(side="right")

    def _create_dimensions_card(self, parent: tk.Frame) -> None:
        """Left grid card displaying board outline, coordinates, dimensions, and orientation."""
        card = CardFrame(parent, title="Board Geometry & Orientation")
        card.grid(row=0, column=0, sticky="nsew", padx=(0, 6))

        # Grid of fields
        grid = tk.Frame(card, bg=COLOR_CARD_BG)
        grid.pack(fill="both", expand=True)

        # Row 0: Outline Status & Orientation
        r0 = tk.Frame(grid, bg=COLOR_CARD_BG)
        r0.pack(fill="x", pady=(0, 6))

        o_box = tk.Frame(r0, bg=COLOR_CARD_BG)
        o_box.pack(side="left", fill="x", expand=True)
        tk.Label(o_box, text="Board Outline:", font=FONT_LABEL, fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_BG).pack(anchor="w")
        self.outline_badge = StatusBadge(o_box, text="Not Detected", status_type="warning")
        self.outline_badge.pack(anchor="w", pady=(2, 0))

        ori_box = tk.Frame(r0, bg=COLOR_CARD_BG)
        ori_box.pack(side="left", fill="x", expand=True)
        tk.Label(ori_box, text="Board Orientation:", font=FONT_LABEL, fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_BG).pack(anchor="w")
        self.orientation_badge = StatusBadge(ori_box, text="-", status_type="neutral")
        self.orientation_badge.pack(anchor="w", pady=(2, 0))

        # Row 1: Dimensions (Width & Height / Length)
        r1 = tk.Frame(grid, bg=COLOR_CARD_BG)
        r1.pack(fill="x", pady=(0, 6))

        self.width_field = InfoField(r1, label="Board Width (Xmax - Xmin):", default_value="-", is_emphasis=True)
        self.width_field.pack(side="left", fill="x", expand=True)

        self.height_field = InfoField(r1, label="Board Length / Height (Ymax - Ymin):", default_value="-", is_emphasis=True)
        self.height_field.pack(side="left", fill="x", expand=True)

        # Row 2: Origin Coordinates
        r2 = tk.Frame(grid, bg=COLOR_CARD_BG)
        r2.pack(fill="x", pady=(0, 6))

        self.origin_x_field = InfoField(r2, label="Board Origin X:", default_value="-")
        self.origin_x_field.pack(side="left", fill="x", expand=True)

        self.origin_y_field = InfoField(r2, label="Board Origin Y:", default_value="-")
        self.origin_y_field.pack(side="left", fill="x", expand=True)

        # Row 3: X Limits (X Minimum & X Maximum)
        r3 = tk.Frame(grid, bg=COLOR_CARD_BG)
        r3.pack(fill="x", pady=(0, 6))

        self.xmin_field = InfoField(r3, label="Board X Minimum (Xmin):", default_value="-")
        self.xmin_field.pack(side="left", fill="x", expand=True)

        self.xmax_field = InfoField(r3, label="Board X Maximum (Xmax):", default_value="-")
        self.xmax_field.pack(side="left", fill="x", expand=True)

        # Row 4: Y Limits (Y Minimum & Y Maximum)
        r4 = tk.Frame(grid, bg=COLOR_CARD_BG)
        r4.pack(fill="x", pady=(0, 6))

        self.ymin_field = InfoField(r4, label="Board Y Minimum (Ymin):", default_value="-")
        self.ymin_field.pack(side="left", fill="x", expand=True)

        self.ymax_field = InfoField(r4, label="Board Y Maximum (Ymax):", default_value="-")
        self.ymax_field.pack(side="left", fill="x", expand=True)

        # Row 5: Coordinate Ranges
        r5 = tk.Frame(grid, bg=COLOR_CARD_BG)
        r5.pack(fill="x", pady=(0, 6))

        self.x_range_field = InfoField(r5, label="X Range [Xmin → Xmax]:", default_value="-")
        self.x_range_field.pack(side="left", fill="x", expand=True)

        self.y_range_field = InfoField(r5, label="Y Range [Ymin → Ymax]:", default_value="-")
        self.y_range_field.pack(side="left", fill="x", expand=True)

        # Row 6: Native Unit & Active Backend
        r6 = tk.Frame(grid, bg=COLOR_CARD_BG)
        r6.pack(fill="x", pady=(2, 0))

        self.unit_field = InfoField(r6, label="Native Unit:", default_value="-")
        self.unit_field.pack(side="left", fill="x", expand=True)

        self.backend_field = InfoField(r6, label="Active Backend Engine:", default_value="-")
        self.backend_field.pack(side="left", fill="x", expand=True)


    def _create_layers_card(self, parent: tk.Frame) -> None:
        """Right grid card displaying copper layers and stackup details."""
        card = CardFrame(parent, title="Copper Layer Stackup")
        card.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

        # Top summary
        top_box = tk.Frame(card, bg=COLOR_CARD_BG)
        top_box.pack(fill="x", pady=(0, 8))

        self.copper_count_field = InfoField(top_box, label="Total Copper Layer Count:", default_value="-", is_emphasis=True)
        self.copper_count_field.pack(side="left", fill="x", expand=True)

        # List of copper layers
        list_lbl = tk.Label(card, text="Identified Copper Layers:", font=FONT_LABEL, fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_BG)
        list_lbl.pack(anchor="w", pady=(0, 4))

        list_container = tk.Frame(card, bg=COLOR_CARD_BG)
        list_container.pack(fill="both", expand=True)

        sb = tk.Scrollbar(list_container)
        sb.pack(side="right", fill="y")

        self.layers_listbox = tk.Listbox(
            list_container,
            font=FONT_VALUE,
            bg="#f8fafc",
            fg=COLOR_TEXT_MAIN,
            selectbackground=COLOR_PRIMARY,
            selectforeground="#ffffff",
            bd=1,
            relief="solid",
            height=6,
            yscrollcommand=sb.set
        )
        self.layers_listbox.pack(side="left", fill="both", expand=True)
        sb.config(command=self.layers_listbox.yview)

        # Note about filtering
        note_lbl = tk.Label(
            card,
            text="* Non-copper layers (Silkscreen, Mask, User, Assembly, DXF, Mechanical) are filtered out.",
            font=(FONT_BODY[0], 8),
            fg=COLOR_TEXT_MUTED,
            bg=COLOR_CARD_BG,
            wraplength=280,
            justify="left"
        )
        note_lbl.pack(anchor="w", pady=(6, 0))

    def _create_status_bar(self) -> None:
        """Bottom status bar with status text and system readiness."""
        status_bar = tk.Frame(self, bg="#0f172a", padx=12, pady=4)
        status_bar.pack(side="bottom", fill="x")

        self.status_msg_var = tk.StringVar(value="System Ready.")
        msg_lbl = tk.Label(
            status_bar,
            textvariable=self.status_msg_var,
            font=(FONT_BODY[0], 9),
            bg="#0f172a",
            fg="#cbd5e1"
        )
        msg_lbl.pack(side="left")

        ver_lbl = tk.Label(
            status_bar,
            text=f"Siemens Xpedition Layout 2510 Protocol Engine | v{APP_VERSION}",
            font=(FONT_BODY[0], 9),
            bg="#0f172a",
            fg="#94a3b8"
        )
        ver_lbl.pack(side="right")

    def _on_select_file(self) -> None:
        """Open file dialog for user to select an Xpedition PCB design file."""
        initial_dir = r"E:\Creative\PCB" if os.path.exists(r"E:\Creative\PCB") else os.getcwd()
        file_selected = filedialog.askopenfilename(
            title="Select Siemens Xpedition PCB Design File",
            initialdir=initial_dir,
            filetypes=XPEDITION_FILE_EXTENSIONS
        )

        if file_selected:
            self.selected_file_path = file_selected
            self.file_path_var.set(file_selected)
            pcb_name = os.path.splitext(os.path.basename(file_selected))[0]
            self.pcb_name_var.set(pcb_name)
            self.log_viewer.log("INFO", f"PCB selected: {file_selected}")
            self.status_msg_var.set(f"Selected: {os.path.basename(file_selected)}")

    def _on_read_pcb(self) -> None:
        """Execute automated extraction from the selected PCB file."""
        file_path = self.file_path_var.get().strip()
        if not file_path or file_path == "No PCB file selected.":
            messagebox.showwarning(
                "No PCB File Selected",
                "Please click 'Select PCB File' to choose an Xpedition PCB file before reading."
            )
            self.log_viewer.log("WARNING", "Read attempted without selecting a PCB file.")
            return

        # Determine backend override
        be_selection = self.backend_var.get()
        force_backend = None
        if "COM" in be_selection:
            force_backend = "com"
        elif "Direct" in be_selection:
            force_backend = "direct"
        elif "Simulation" in be_selection:
            force_backend = "mock"

        self.extractor.force_backend = force_backend
        self.status_msg_var.set("Reading PCB information...")
        self.read_btn.config(state="disabled", text="Reading...")
        self.update_idletasks()

        try:
            info = self.extractor.extract(file_path)
            self.current_pcb_info = info
            self._update_display(info)

            if not info.extraction_successful:
                err_msg = info.error_message or "Unable to read PCB file."
                messagebox.showerror("Extraction Error", err_msg)
                self.status_msg_var.set(f"Error: {err_msg}")
            else:
                self.status_msg_var.set(f"Successfully read PCB: {info.pcb_name} ({info.total_copper_layers} copper layers)")
                
        except Exception as ex:
            self.log_viewer.log("ERROR", f"Unhandled error reading PCB: {str(ex)}")
            messagebox.showerror("Extraction Exception", f"Unexpected error reading PCB:\n{str(ex)}")
            self.status_msg_var.set("Extraction failed.")
        finally:
            self.read_btn.config(state="normal", text="⚡ Read PCB")

    def _update_display(self, info: PCBInfo) -> None:
        """Update all UI fields from the extracted PCBInfo data structure."""
        unit = info.native_unit

        # Basic fields
        self.pcb_name_var.set(info.pcb_name or "-")
        self.unit_field.set_value(unit)
        self.backend_field.set_value(info.reader_backend)

        # Copper Layers
        if info.total_copper_layers > 0:
            self.copper_count_field.set_value(f"{info.total_copper_layers} Layers")
        else:
            self.copper_count_field.set_value("Not Determined")

        self.layers_listbox.delete(0, "end")
        if info.copper_layer_names:
            for idx, name in enumerate(info.copper_layer_names, start=1):
                self.layers_listbox.insert("end", f"{idx}. {name}")
        else:
            self.layers_listbox.insert("end", "(No copper layers detected)")

        # Board Outline & Coordinates
        if info.board_outline_detected:
            self.outline_badge.set_status(OUTLINE_DETECTED, "success")
            
            # Orientation badge
            ori = info.orientation
            ori_type = "success" if ori == ORIENTATION_LANDSCAPE else "warning"
            self.orientation_badge.set_status(ori, ori_type)

            # Dimensions
            self.width_field.set_value(f"{info.board_width:.2f} {unit}")
            self.height_field.set_value(f"{info.board_height:.2f} {unit}")

            # Origin
            self.origin_x_field.set_value(f"X = {info.board_origin_x:.2f} {unit}")
            self.origin_y_field.set_value(f"Y = {info.board_origin_y:.2f} {unit}")

            # Limits
            self.xmin_field.set_value(f"{info.board_min_x:.2f} {unit}")
            self.xmax_field.set_value(f"{info.board_max_x:.2f} {unit}")
            self.ymin_field.set_value(f"{info.board_min_y:.2f} {unit}")
            self.ymax_field.set_value(f"{info.board_max_y:.2f} {unit}")

            # Ranges
            self.x_range_field.set_value(f"{info.board_min_x:.2f} → {info.board_max_x:.2f} {unit}")
            self.y_range_field.set_value(f"{info.board_min_y:.2f} → {info.board_max_y:.2f} {unit}")
        else:
            self.outline_badge.set_status(OUTLINE_NOT_DETECTED, "error")
            self.orientation_badge.set_status("Unknown", "neutral")
            self.width_field.set_value("-")
            self.height_field.set_value("-")
            self.origin_x_field.set_value(f"X = {info.board_origin_x:.2f} {unit}")
            self.origin_y_field.set_value(f"Y = {info.board_origin_y:.2f} {unit}")
            self.xmin_field.set_value("-")
            self.xmax_field.set_value("-")
            self.ymin_field.set_value("-")
            self.ymax_field.set_value("-")
            self.x_range_field.set_value("-")
            self.y_range_field.set_value("-")

