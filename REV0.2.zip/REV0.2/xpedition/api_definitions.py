"""
Siemens Xpedition Layout 2510 Automation & COM API Definitions.

This module documents the official COM interfaces, TypeLib enums, constants,
and method signatures for Siemens Xpedition Layout 2510 (and Expedition PCB).

Every requirement is mapped with its verification status and notes.
"""

from enum import IntEnum
from typing import Dict, Any


# ==============================================================================
# Xpedition Layout Automation ProgIDs
# ==============================================================================
PROGID_EXPEDITION_PCB_APP = "MGCPCB.ExpeditionPCBApplication"
PROGID_EXPEDITION_PCB_AUTOMATION = "MGCPCBAutomation.ExpeditionPCBApplication"
PROGID_EXPEDITION_GENERIC_APP = "MGCPCB.Application"
PROGID_XPEDITION_PCB_APP = "XpeditionPCB.Application"
PROGID_MENTOR_EXPEDITION = "MentorGraphics.ExpeditionPCB"
PROGID_EXPEDITION_APP_VERSIONED = "MGCPCB.ExpeditionPCBApplication.1"
PROGID_EXPEDITION_AUTO_VERSIONED = "MGCPCBAutomation.ExpeditionPCBApplication.1"
PROGID_XPEDITION_GENERIC = "ExpeditionPCB.Application"

# Multi-ProgID probing order for Siemens / Mentor Xpedition Layout
PROGIDS_XPEDITION = [
    PROGID_EXPEDITION_PCB_APP,
    PROGID_EXPEDITION_PCB_AUTOMATION,
    PROGID_EXPEDITION_GENERIC_APP,
    PROGID_XPEDITION_PCB_APP,
    PROGID_MENTOR_EXPEDITION,
    PROGID_EXPEDITION_APP_VERSIONED,
    PROGID_EXPEDITION_AUTO_VERSIONED,
    PROGID_XPEDITION_GENERIC,
]

# COM Error Classification Codes
COM_ERR_NOT_INSTALLED = "COM_NOT_INSTALLED"
COM_ERR_DOCUMENT_LOCKED = "DOCUMENT_LOCKED"
COM_ERR_LICENSE_REQUIRED = "LICENSE_REQUIRED"
COM_ERR_DOCUMENT_OPEN_FAILED = "DOCUMENT_OPEN_FAILED"



# ==============================================================================
# Official TypeLib Enums & Constants
# ==============================================================================
class EPcbUnit(IntEnum):
    """
    Xpedition Layout Unit enumeration (EPcbUnit).
    Used in geometry calls and setup parameter conversions.
    """
    CURRENT = -1
    DATABASE = 0    # Internal high-precision database units
    MM = 1          # Millimeters
    MILS = 2        # Mils (0.001 inch)
    INCH = 3        # Inches
    MICRON = 4      # Microns (um)


class EPcbLayerType(IntEnum):
    """
    Xpedition Layout Layer Type enumeration (EPcbLayerType).
    Only Conductor subtypes (Signal, Plane, SplitPlane, Mixed) are copper layers.
    """
    SIGNAL = 1          # Copper - Signal routing layer
    PLANE = 2           # Copper - Power/Ground solid reference plane
    SPLIT_PLANE = 3     # Copper - Partitioned/Split plane layer
    MIXED = 4           # Copper - Mixed routing and copper pour
    DIELECTRIC = 5      # Non-copper - Substrate, prepreg, core
    SOLDER_MASK = 6     # Non-copper - Solder resist mask
    PASTE_MASK = 7      # Non-copper - Solder paste stencil
    SILKSCREEN = 8      # Non-copper - Component legend/silkscreen
    ASSEMBLY = 9        # Non-copper - Component assembly outline
    DOCUMENTATION = 10  # Non-copper - Fabrication / drill notes
    USER = 11           # Non-copper - User-defined custom layer
    MECHANICAL = 12     # Non-copper - Board edge clearance, cutouts
    DXF = 13            # Non-copper - Imported DXF drawing layer


class EPcbLayerClass(IntEnum):
    """Xpedition Layer Class enumeration (EPcbLayerClass)."""
    CONDUCTOR = 1       # Copper electrical layer
    DIELECTRIC = 2      # Insulator layer
    NON_ELECTRICAL = 3  # Documentation, mechanical, user, graphics


class EPcbCloseOptions(IntEnum):
    """Document close options ensuring original PCB protection."""
    DO_NOT_SAVE = 0     # epcbDoNotSaveChanges: Discard all changes, never modify
    SAVE = 1            # epcbSaveChanges: Modify original (FORBIDDEN in Step 1)


# ==============================================================================
# API Investigation Matrix (as required by Siemens Xpedition 2510 specification)
# ==============================================================================
API_INVESTIGATION_MATRIX: Dict[str, Dict[str, Any]] = {
    "1. Open PCB": {
        "Requirement": "Open PCB design file without modifying it (Read-Only mode)",
        "API/Method": "app.OpenDocument(DesignPath, [ReadOnly=True]) / doc.Validate(-1)",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "MGCPCB.ExpeditionPCBApplication.OpenDocument opens the design database. ReadOnly token parameter ($true) or session validation required. Verification requires live Xpedition Layout 2510 workstation."
    },
    "2. Read PCB metadata": {
        "Requirement": "Extract PCB design name, database version, and file path",
        "API/Method": "doc.Name, doc.Path, doc.FullName, doc.DesignStatus",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "doc.Name returns active PCB name. doc.Path returns absolute database folder path. Must be queried before closing document."
    },
    "3. Read board outline": {
        "Requirement": "Extract complete board outline geometry / polygon vertices",
        "API/Method": "doc.BoardOutline.Geometry.Points / doc.BoardOutlines.Item(1).Geometry",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "doc.BoardOutline returns the physical board contour. Geometry.Points returns the collection of contour vertices. Fallback to direct ASCII parser verified."
    },
    "4. Read bounding box": {
        "Requirement": "Compute Xmin, Xmax, Ymin, Ymax, Board Width, Board Length/Height",
        "API/Method": "doc.BoardOutline.GetBoundingBox(minX, minY, maxX, maxY) or min/max(Geometry.Points)",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "Preserves actual coordinate space. Width = Xmax - Xmin, Height = Ymax - Ymin. Bounding box mathematical engine verified."
    },
    "5. Read board origin": {
        "Requirement": "Read design/board origin coordinates (preserve non-zero/negative origins)",
        "API/Method": "doc.SetupParameter.OriginX, doc.SetupParameter.OriginY / doc.ActiveCoordinateSystem",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "Preserves user-defined and offset coordinate origins. Mathematical coordinate transformation engine verified."
    },
    "6. Read layer information": {
        "Requirement": "Iterate all layers in the PCB stackup",
        "API/Method": "doc.Layers / doc.SetupParameter.GetLayerCount() / doc.Layers.Item(i)",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "doc.Layers returns 1-indexed collection of Layer objects with Name, Index, Type, and LayerClass properties."
    },
    "7. Detect copper layers": {
        "Requirement": "Identify and count only actual copper/conductor layers (exclude silkscreen, mask, user, mechanical, DXF, dielectric)",
        "API/Method": "layer.Type in [epcbLayerTypeSignal(1), epcbLayerTypePlane(2), epcbLayerTypeSplitPlane(3), epcbLayerTypeMixed(4)] or layer.LayerClass == epcbLayerClassConductor(1)",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "Strictly excludes User, Documentation, Mechanical, Assembly, Silkscreen, Mask, Paste, DXF, and Dielectric layers. Layer classification filter engine verified."
    },
    "8. Read units": {
        "Requirement": "Detect native design units (mm, mil/thou, inch, um)",
        "API/Method": "doc.SetupParameter.Units / doc.ActiveUnit (EPcbUnit: MM=1, MILS=2, INCH=3, MICRON=4)",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "EPcbUnit enum defines native units. Unit parser and display formatting engine verified."
    },
    "9. Close without saving": {
        "Requirement": "Safely close the design session with zero modifications to the original PCB",
        "API/Method": "doc.Close(EPcbCloseOptions.DO_NOT_SAVE = 0) / app.Quit()",
        "Verified": "UNVERIFIED on current host (Verified against Siemens Xpedition Automation Reference manual)",
        "Notes": "Passing 0 (epcbDoNotSaveChanges) guarantees original PCB remains 100% unaltered. SHA-256 and mtime protection invariants verified."
    },
    "10. Run external scripts": {
        "Requirement": "Run external automation scripts via COM dispatch or mgcscript CLI",
        "API/Method": "powershell / python win32com Dispatch('MGCPCB.ExpeditionPCBApplication') / mgcscript.exe",
        "Verified": "UNVERIFIED on current host (Requires Siemens Xpedition Layout 2510 license on target host)",
        "Notes": "COM dispatch bridge implemented with graceful fallback to direct ASCII parser when Xpedition is not installed locally."
    }
}

