"""
Siemens Xpedition Layout 2510 COM Automation Reader.

Interacts directly with the official Siemens Xpedition Layout COM object model
(MGCPCB.ExpeditionPCBApplication, MGCPCBAutomation.ExpeditionPCBApplication, etc.)
to read metadata, layer stackup, board outline geometry, and units without modifying
the PCB design.
"""

import os
import sys
import json
import subprocess
from typing import Optional, List, Tuple
from .interface import IPCBReader, LogCallback
from .models import PCBInfo, Point, LayerInfo
from .layer_detector import LayerDetector
from .outline_detector import OutlineDetector
from .api_definitions import (
    PROGIDS_XPEDITION,
    PROGID_EXPEDITION_PCB_APP,
    COM_ERR_NOT_INSTALLED,
    COM_ERR_DOCUMENT_LOCKED,
    COM_ERR_LICENSE_REQUIRED,
    COM_ERR_DOCUMENT_OPEN_FAILED,
    EPcbUnit,
    EPcbCloseOptions,
)


class XpeditionCOMReader(IPCBReader):
    """
    COM Automation reader for Siemens Xpedition Layout 2510.
    Supports multi-ProgID probing, active document reuse, and categorized diagnostics.
    """

    def __init__(self, log_cb: Optional[LogCallback] = None):
        super().__init__(log_cb)
        self._matched_progid: Optional[str] = None
        self._com_status: str = "UNCHECKED"
        self._com_available = self._probe_com_availability()

    def _probe_com_availability(self) -> bool:
        """
        Check if any Siemens/Mentor Xpedition COM automation ProgID is registered on the system.
        Probes all known ProgIDs in order.
        """
        # 1. Try python win32com if installed
        try:
            import win32com.client
            for progid in PROGIDS_XPEDITION:
                try:
                    # Test if CLSID can be resolved from ProgID
                    clsid = win32com.client.gencache.CLSIDForProgID(progid) if hasattr(win32com.client, "gencache") else None
                    if clsid:
                        self._matched_progid = progid
                        self._com_status = f"AVAILABLE ({progid})"
                        return True
                except Exception:
                    pass
        except ImportError:
            pass

        # 2. Try native PowerShell Type reflection check across all ProgIDs
        progid_list_str = "@(" + ", ".join(f"'{p}'" for p in PROGIDS_XPEDITION) + ")"
        ps_check = f"""
        $progids = {progid_list_str}
        foreach ($p in $progids) {{
            try {{
                $t = [System.Type]::GetTypeFromProgID($p)
                if ($t -ne $null) {{
                    Write-Output $p
                    exit 0
                }}
            }} catch {{}}
        }}
        exit 1
        """
        try:
            res = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_check],
                capture_output=True,
                text=True,
                timeout=6
            )
            if res.returncode == 0 and res.stdout.strip():
                matched = res.stdout.strip().splitlines()[0].strip()
                self._matched_progid = matched
                self._com_status = f"AVAILABLE ({matched})"
                return True
            else:
                self._com_status = "NOT_INSTALLED"
                return False
        except Exception as ex:
            self._com_status = f"PROBE_ERROR ({str(ex)})"
            return False

    def is_available(self) -> bool:
        """Returns True if Xpedition Layout COM automation is available on this system."""
        return self._com_available

    def get_status_description(self) -> str:
        """Returns human-readable COM engine status."""
        if self._com_available:
            return f"COM Ready (ProgID: {self._matched_progid or PROGID_EXPEDITION_PCB_APP})"
        return "COM Offline / Not Registered"

    def read_pcb(self, file_path: str) -> PCBInfo:
        """
        Open the selected Xpedition PCB file via COM automation, extract all
        required parameters, and close the session without saving.
        """
        abs_path = os.path.abspath(file_path)
        pcb_name = os.path.splitext(os.path.basename(file_path))[0]
        
        info = PCBInfo(
            pcb_name=pcb_name,
            file_path=abs_path,
            reader_backend="Siemens Xpedition 2510 COM Automation",
            is_read_only=True
        )

        if not os.path.exists(abs_path):
            self.log("ERROR", f"PCB file not found: {abs_path}")
            info.extraction_successful = False
            info.error_message = f"Unable to read PCB file: File does not exist ({abs_path})."
            return info

        self.log("INFO", f"PCB selected: {abs_path}")
        self.log("INFO", "Opening PCB in Read-Only mode via Xpedition COM interface...")

        # Execute extraction via PowerShell COM bridge
        try:
            success, raw_data, err = self._execute_com_extraction(abs_path)
            if not success:
                self.log("ERROR", f"COM extraction failed: {err}")
                info.extraction_successful = False
                info.error_message = err or "PCB format or Xpedition API interface could not be accessed."
                return info

            # Parse extracted raw data
            self._populate_info_from_com_data(info, raw_data)
            info.extraction_successful = True
            self.log("INFO", "PCB closed without saving (Original PCB protected)")
            return info

        except Exception as ex:
            self.log("ERROR", f"Exception during COM automation: {str(ex)}")
            info.extraction_successful = False
            info.error_message = f"Xpedition API error: {str(ex)}"
            return info

    def _execute_com_extraction(self, file_path: str) -> Tuple[bool, dict, str]:
        """
        Executes Xpedition automation via native Windows COM bridge script.
        Iterates multi-ProgID interfaces, checks running document instances, and handles errors.
        """
        progid_list_ps = "@(" + ", ".join(f'"{p}"' for p in PROGIDS_XPEDITION) + ")"

        script = f"""
param([string]$FilePath)
$ErrorActionPreference = "Stop"
try {{
    $progids = {progid_list_ps}
    $app = $null
    $isNewInstance = $false
    $activeProgid = $null

    # 1. Try connecting to an active running instance of Xpedition
    foreach ($p in $progids) {{
        try {{
            $app = [System.Runtime.InteropServices.Marshal]::GetActiveObject($p)
            if ($app -ne $null) {{
                $activeProgid = $p
                break
            }}
        }} catch {{}}
    }}

    # 2. If no active instance, instantiate a new COM server
    if ($app -eq $null) {{
        foreach ($p in $progids) {{
            try {{
                $app = New-Object -ComObject $p
                if ($app -ne $null) {{
                    $activeProgid = $p
                    $isNewInstance = $true
                    break
                }}
            }} catch {{}}
        }}
    }}

    if ($app -eq $null) {{
        Write-Output (ConvertTo-Json @{{
            status = "error"
            error_code = "{COM_ERR_NOT_INSTALLED}"
            message = "Siemens Xpedition Layout COM Automation is not registered or installed on this system. (Checked ProgIDs: MGCPCB.ExpeditionPCBApplication, MGCPCBAutomation.ExpeditionPCBApplication, MGCPCB.Application, XpeditionPCB.Application). Use Direct File Parser or install Siemens Xpedition Layout."
        }})
        exit 0
    }}

    # 3. Check if document is already active in Xpedition
    $doc = $null
    try {{
        if ($app.ActiveDocument -ne $null) {{
            $activePath = ""
            try {{ $activePath = [string]$app.ActiveDocument.FullName }} catch {{ try {{ $activePath = [string]$app.ActiveDocument.Path }} catch {{}} }}
            if ($activePath -and ($activePath.Trim().ToLower() -eq $FilePath.Trim().ToLower())) {{
                $doc = $app.ActiveDocument
            }}
        }}
    }} catch {{}}

    # 4. Open Document in Read-Only Mode (original PCB protection)
    if ($doc -eq $null) {{
        try {{
            $doc = $app.OpenDocument($FilePath, $true)
        }} catch {{
            $exMsg = [string]$_.Exception.Message
            if ($exMsg -match "license" -or $exMsg -match "FLEXlm" -or $exMsg -match "FLEXnet") {{
                Write-Output (ConvertTo-Json @{{
                    status = "error"
                    error_code = "{COM_ERR_LICENSE_REQUIRED}"
                    message = "Siemens Xpedition license not found or license server unavailable."
                }})
                if ($isNewInstance) {{ try {{ $app.Quit() }} catch {{}} }}
                exit 0
            }} elseif ($exMsg -match "lock" -or $exMsg -match "in use" -or $exMsg -match "exclusive" -or $exMsg -match "sharing violation") {{
                Write-Output (ConvertTo-Json @{{
                    status = "error"
                    error_code = "{COM_ERR_DOCUMENT_LOCKED}"
                    message = "PCB file is locked or currently open exclusively by another process."
                }})
                if ($isNewInstance) {{ try {{ $app.Quit() }} catch {{}} }}
                exit 0
            }} else {{
                $doc = $null
            }}
        }}
    }}

    if ($doc -eq $null) {{
        try {{ $doc = $app.ActiveDocument }} catch {{}}
    }}

    if ($doc -eq $null) {{
        Write-Output (ConvertTo-Json @{{
            status = "error"
            error_code = "{COM_ERR_DOCUMENT_OPEN_FAILED}"
            message = "Unable to read PCB file: Failed to open document via Xpedition COM interface."
        }})
        if ($isNewInstance) {{ try {{ $app.Quit() }} catch {{}} }}
        exit 0
    }}

    # Validate session token if required by Xpedition licensing
    try {{
        $key = $doc.Validate(-1)
        if ($key -ne $null -and $key -ne 0) {{
            $doc.Validate($key)
        }}
    }} catch {{}}

    # 5. Read PCB Metadata
    $docName = ""
    try {{ $docName = [string]$doc.Name }} catch {{}}

    # 6. Read Units
    $unitStr = "mm"
    try {{
        $unitVal = $doc.SetupParameter.Units
        if ($unitVal -eq 2) {{ $unitStr = "mil" }}
        elseif ($unitVal -eq 3) {{ $unitStr = "inch" }}
        elseif ($unitVal -eq 4) {{ $unitStr = "um" }}
        else {{ $unitStr = "mm" }}
    }} catch {{
        $unitStr = "mm"
    }}

    # 7. Read Layer Stack
    $layers = @()
    try {{
        $layerCount = $doc.Layers.Count
        for ($i = 1; $i -le $layerCount; $i++) {{
            $l = $doc.Layers.Item($i)
            $layers += @{{
                index = $i
                name = [string]$l.Name
                type = [int]$l.Type
                class = [int]$l.LayerClass
            }}
        }}
    }} catch {{}}

    # 8. Read Board Outline & Origin
    $outlinePoints = @()
    $originX = 0.0
    $originY = 0.0
    try {{
        $originX = [double]$doc.SetupParameter.OriginX
        $originY = [double]$doc.SetupParameter.OriginY
    }} catch {{}}

    $outlineDetected = $false
    try {{
        $outline = $doc.BoardOutline
        if ($outline -ne $null) {{
            $pts = $outline.Geometry.Points
            foreach ($p in $pts) {{
                $outlinePoints += @{{ x = [double]$p.x; y = [double]$p.y }}
            }}
            if ($outlinePoints.Count -ge 3) {{
                $outlineDetected = $true
            }}
        }}
    }} catch {{}}

    # 9. Close Document Without Saving (epcbDoNotSaveChanges = 0)
    try {{
        $doc.Close(0)
    }} catch {{}}

    if ($isNewInstance) {{
        try {{ $app.Quit() }} catch {{}}
    }}

    $result = @{{
        status = "success"
        name = $docName
        unit = $unitStr
        layers = $layers
        origin_x = $originX
        origin_y = $originY
        outline_detected = $outlineDetected
        outline_points = $outlinePoints
        progid = $activeProgid
    }}

    Write-Output (ConvertTo-Json $result -Depth 5)
}} catch {{
    Write-Output (ConvertTo-Json @{{
        status = "error"
        error_code = "UNHANDLED_EXCEPTION"
        message = $_.Exception.Message
    }})
}}
"""
        try:
            res = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script, "-FilePath", file_path],
                capture_output=True,
                text=True,
                timeout=18
            )
            stdout = res.stdout.strip()
            if not stdout:
                return False, {}, "PCB format or Xpedition API interface could not be accessed. (COM bridge returned no output)"

            data = json.loads(stdout)
            if data.get("status") == "success":
                return True, data, ""
            else:
                return False, {}, data.get("message", "Unknown COM error")
        except subprocess.TimeoutExpired:
            return False, {}, "Xpedition COM automation timed out."
        except Exception as e:
            return False, {}, f"PCB format or Xpedition API interface could not be accessed: {str(e)}"

    def _populate_info_from_com_data(self, info: PCBInfo, data: dict) -> None:
        """Parse raw COM dictionary and update PCBInfo."""
        info.pcb_name = data.get("name") or info.pcb_name
        info.native_unit = data.get("unit", "mm")
        info.board_origin_x = float(data.get("origin_x", 0.0))
        info.board_origin_y = float(data.get("origin_y", 0.0))
        if data.get("progid"):
            info.reader_backend = f"Siemens Xpedition COM Automation ({data.get('progid')})"

        # Process layers
        self.log("INFO", "Reading layer stack...")
        raw_layers = data.get("layers", [])
        all_layers = []
        for l in raw_layers:
            layer_info = LayerDetector.classify_from_api(
                name=l.get("name", ""),
                index=int(l.get("index", 0)),
                layer_type_code=int(l.get("type", 0)),
                layer_class_code=int(l.get("class", 0))
            )
            all_layers.append(layer_info)

        info.all_layers = all_layers
        copper_layers = LayerDetector.filter_copper_layers(all_layers)
        info.total_copper_layers = len(copper_layers)
        info.copper_layer_names = [l.name for l in copper_layers]
        self.log("INFO", f"Copper layers detected: {info.total_copper_layers}")

        # Process outline
        self.log("INFO", "Reading board outline...")
        pts_data = data.get("outline_points", [])
        points = [Point(x=float(p["x"]), y=float(p["y"])) for p in pts_data]
        info.outline_points = points

        if points and OutlineDetector.validate_outline(points):
            info.board_outline_detected = True
            self.log("INFO", f"Board outline detected ({len(points)} vertices)")
            self.log("INFO", "Calculating bounding box...")
            bbox = OutlineDetector.calculate_bounding_box(points)
            if bbox:
                info.board_min_x = bbox.min_x
                info.board_max_x = bbox.max_x
                info.board_min_y = bbox.min_y
                info.board_max_y = bbox.max_y
                width, height, orientation = OutlineDetector.calculate_dimensions(bbox)
                info.board_width = width
                info.board_height = height
                info.orientation = orientation
                self.log("INFO", f"Board width: {width:.2f} {info.native_unit}")
                self.log("INFO", f"Board height: {height:.2f} {info.native_unit}")
                self.log("INFO", f"Orientation: {orientation}")
        else:
            info.board_outline_detected = False
            self.log("WARNING", "Board outline not detected.")
            info.calculate_dimensions()
