"""
Direct Siemens Xpedition ASCII, HKP, Gerber, and Binary Stream File Reader.

Parses Siemens Xpedition ASCII layout databases, .hkp, RS-274X Gerber board outlines,
and inspects binary .pcb / .lyt databases directly in 100% read-only mode without
modifying the source design files.
"""

import os
import re
from typing import Optional, List, Tuple
from .interface import IPCBReader, LogCallback
from .models import PCBInfo, Point, LayerInfo, LayerClass, ConductorSubtype
from .layer_detector import LayerDetector
from .outline_detector import OutlineDetector


class XpeditionDirectFileReader(IPCBReader):
    """
    Direct parser for Siemens Xpedition ASCII/HKP design files, Gerber outlines,
    and binary PCB stream inspector.
    """

    def is_available(self) -> bool:
        """Direct file parser is always available offline."""
        return True

    def read_pcb(self, file_path: str) -> PCBInfo:
        """
        Reads an Xpedition PCB/HKP/Gerber file directly in 100% read-only mode.
        """
        abs_path = os.path.abspath(file_path)
        pcb_name = os.path.splitext(os.path.basename(file_path))[0]
        
        info = PCBInfo(
            pcb_name=pcb_name,
            file_path=abs_path,
            reader_backend="Xpedition Direct File Parser (Read-Only)",
            is_read_only=True
        )

        if not os.path.exists(abs_path):
            self.log("ERROR", f"PCB file not found: {abs_path}")
            info.extraction_successful = False
            info.error_message = f"Unable to read PCB file: File does not exist ({abs_path})."
            return info

        self.log("INFO", f"PCB selected: {abs_path}")
        self.log("INFO", "Opening PCB in Read-Only mode...")

        try:
            # Check for binary file (contains null bytes in initial chunk)
            with open(abs_path, "rb") as bf:
                chunk = bf.read(8192)
                if b"\x00" in chunk:
                    return self._inspect_binary_stream(abs_path, info)

            # Read text content
            with open(abs_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            if not content.strip():
                self.log("ERROR", "PCB file is empty.")
                info.extraction_successful = False
                info.error_message = "Unable to read PCB file: File is empty."
                return info

            # Check if RS-274X Gerber file
            if self._is_gerber_file(content, abs_path):
                self.log("INFO", "Detected RS-274X Gerber format. Parsing board outline...")
                is_valid = self._parse_gerber_content(content, info)
            else:
                self.log("INFO", "Parsing Siemens Xpedition HKP / ASCII layout database...")
                is_valid = self._parse_hkp_content(content, info)

            if not is_valid:
                self.log("ERROR", "File does not contain valid Xpedition PCB or Gerber structure.")
                info.extraction_successful = False
                info.error_message = "Unable to read PCB file: Invalid or unsupported PCB format."
                return info

            info.extraction_successful = True
            self.log("INFO", "PCB closed without saving (Original PCB protected)")
            return info

        except Exception as ex:
            self.log("ERROR", f"Error parsing PCB file: {str(ex)}")
            info.extraction_successful = False
            info.error_message = f"Unable to read PCB file: {str(ex)}"
            return info

    def _is_gerber_file(self, content: str, file_path: str) -> bool:
        """Check if file has Gerber extension or RS-274X header commands."""
        ext = os.path.splitext(file_path)[1].lower()
        if ext in [".gko", ".gm1", ".gm2", ".gm3", ".gbo", ".outline", ".gbr", ".ger"]:
            return True
        # Check RS-274X header directives in first 50 lines
        lines = content.splitlines()[:50]
        gerber_hints = ["%FS", "%MO", "G04", "%IP", "%LN", "%ADD", "D02*", "D01*"]
        matched_hints = sum(1 for line in lines if any(h in line for h in gerber_hints))
        return matched_hints >= 2

    def _parse_gerber_content(self, content: str, info: PCBInfo) -> bool:
        """
        Parse RS-274X Gerber board outline file (.GKO, .GM1, .GBO, .OUTLINE).
        Extracts outline contour vertices and calculates board dimensions and orientation.
        """
        info.reader_backend = "RS-274X Gerber Outline Parser (Read-Only)"
        
        # 1. Detect Unit
        unit = "mm"
        if "%MOMM*%" in content or "%MOMM" in content:
            unit = "mm"
        elif "%MOIN*%" in content or "%MOIN" in content:
            unit = "inch"
        info.native_unit = unit
        self.log("INFO", f"Detected Gerber native unit: {unit}")

        # 2. Detect Coordinate Format Specification (%FSLAX24Y24*% / %FSLAX35Y35*% etc.)
        divisor = 10000.0  # default 4 decimal digits
        fs_match = re.search(r"%FS[A-Z]*X(\d)(\d)Y(\d)(\d)", content)
        if fs_match:
            dec_digits = int(fs_match.group(2))
            divisor = float(10 ** dec_digits)
            self.log("INFO", f"Gerber coordinate format: {fs_match.group(1)}.{dec_digits} (divisor {divisor:.0f})")

        # 3. Parse commands and extract vertices
        points: List[Point] = []
        cur_x = 0.0
        cur_y = 0.0
        
        # Split by command delimiters
        commands = re.split(r"[*;\n\r]+", content)
        for cmd in commands:
            cmd = cmd.strip()
            if not cmd or cmd.startswith("G04") or cmd.startswith("%"):
                continue

            # Extract X, Y, and D-codes
            has_x = False
            has_y = False
            
            x_match = re.search(r"X([-+]?\d+)", cmd)
            if x_match:
                cur_x = float(int(x_match.group(1))) / divisor
                has_x = True

            y_match = re.search(r"Y([-+]?\d+)", cmd)
            if y_match:
                cur_y = float(int(y_match.group(1))) / divisor
                has_y = True

            d_match = re.search(r"D0?([123])", cmd)
            if d_match:
                d_code = int(d_match.group(1))
                if d_code in (1, 2) and (has_x or has_y or len(points) == 0):
                    points.append(Point(x=cur_x, y=cur_y))
            elif has_x or has_y:
                # Coordinate word without explicit D-code continues current contour
                if points:
                    points.append(Point(x=cur_x, y=cur_y))

        # Check layer comments
        layer_comment = re.search(r"G04\s+(?:Layer|Name|File):\s*([^\*]+)\*", content, re.IGNORECASE)
        outline_layer_name = layer_comment.group(1).strip() if layer_comment else "Board Outline (Gerber)"

        info.all_layers = [
            LayerInfo(
                index=1,
                name=outline_layer_name,
                layer_class=LayerClass.MECHANICAL,
                is_copper=False,
                original_type_str="Gerber Board Outline"
            )
        ]
        info.total_copper_layers = 0
        info.copper_layer_names = []

        info.outline_points = points
        if points and OutlineDetector.validate_outline(points):
            info.board_outline_detected = True
            self.log("INFO", f"Gerber board outline detected ({len(points)} vertices)")
            self.log("INFO", "Calculating bounding box...")
            bbox = OutlineDetector.calculate_bounding_box(points)
            if bbox:
                info.board_min_x = bbox.min_x
                info.board_max_x = bbox.max_x
                info.board_min_y = bbox.min_y
                info.board_max_y = bbox.max_y
                width, height, orientation = OutlineDetector.calculate_dimensions(bbox)
                info.board_width = width
                info.board_height = height
                info.orientation = orientation
                info.board_origin_x = bbox.min_x
                info.board_origin_y = bbox.min_y
                self.log("INFO", f"Board width: {width:.2f} {info.native_unit}")
                self.log("INFO", f"Board height: {height:.2f} {info.native_unit}")
                self.log("INFO", f"Orientation: {orientation}")
            return True
        else:
            info.board_outline_detected = False
            info.calculate_dimensions()
            return len(points) > 0

    def _parse_hkp_content(self, content: str, info: PCBInfo) -> bool:
        """
        Full parser for Siemens Xpedition HKP / ASCII layout database files.
        Handles .FILETYPE LAYOUT, JOBPREFS, LAYER_NAME_MAP, !.NUMBER_OF_LAYERS,
        ..POLYARC_PATH / ...XYR coordinate tuples, board origin, native units,
        and layer stackup definitions.
        """
        lines = content.splitlines()

        # Check for Xpedition markers / keywords
        xpedition_keywords = [
            ".FILETYPE", "..FILE_TYPE", "..VERSION", ".VERSION", "!.VERSION",
            "JOBPREFS", ".JOBPREFS", "..JOBPREFS",
            "..DESIGN_NAME", ".NAME", "..UNITS", ".UNITS",
            "!.NUMBER_OF_LAYERS", ".NUMBER_OF_LAYERS",
            "LAYER_NAME_MAP", ".LAYER_NAME_MAP",
            "..LAYER_STACKUP", "..STACKUP", ".STACK", "..CONDUCTOR_LAYER",
            "..BOARD_OUTLINE", ".BOARD_OUTLINE", "..ROUTE_BORDER", ".ROUTE_BORDER",
            "..BOARD_BORDER", ".BOARD_BORDER", "..OUTLINE", ".OUTLINE",
            "..BOARD_ORIGIN", ".BOARD_ORIGIN", "..ORIGIN", ".ORIGIN",
            "..POLYARC_PATH", ".POLYARC_PATH", "...XYR", "..XYR", "..XY", ".PT"
        ]
        has_marker = any(
            any(k in line.strip().upper() for k in xpedition_keywords)
            for line in lines
        )

        if not has_marker:
            return False

        # 1. Parse Design Name
        for line in lines:
            line_strip = line.strip()
            line_upper = line_strip.upper()
            if line_upper.startswith("..DESIGN_NAME") or line_upper.startswith(".NAME") or line_upper.startswith(".JOB_NAME"):
                m = re.search(r'["\']([^"\']+)["\']', line_strip)
                if m:
                    info.pcb_name = m.group(1).strip()
                else:
                    parts = line_strip.split(maxsplit=1)
                    if len(parts) > 1:
                        info.pcb_name = parts[1].strip()
                break

        # 2. Parse Units (.UNITS TH / .UNITS MM / ..UNITS TH / .JOBPREFS .UNITS MM etc.)
        unit = "mm"
        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            if line_upper.startswith(".UNITS") or line_upper.startswith("..UNITS") or line_upper.startswith("UNITS"):
                if any(u in line_upper for u in ["TH", "MIL", "THOU", "MILS"]):
                    unit = "mil"
                elif "IN" in line_upper:
                    unit = "inch"
                elif any(u in line_upper for u in ["UM", "MICRON"]):
                    unit = "um"
                else:
                    unit = "mm"
                break
        info.native_unit = unit
        self.log("INFO", f"Detected native unit: {unit}")

        # 3. Parse Origin (.BOARD_ORIGIN \n ..XY x, y or .ORIGIN x y or ..ORIGIN x y)
        origin_x, origin_y = 0.0, 0.0
        in_origin_block = False
        origin_found = False

        for idx, line in enumerate(lines):
            line_clean = line.strip()
            line_upper = line_clean.upper()

            if line_upper.startswith(".BOARD_ORIGIN") or line_upper.startswith("..BOARD_ORIGIN") or \
               line_upper.startswith(".ORIGIN") or line_upper.startswith("..ORIGIN") or \
               line_upper.startswith("..DESIGN_ORIGIN") or line_upper.startswith("..USER_ORIGIN"):
                
                # Check if coordinates are on the same line
                coords_same_line = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line_clean)
                if len(coords_same_line) >= 2:
                    origin_x, origin_y = float(coords_same_line[0]), float(coords_same_line[1])
                    origin_found = True
                    break
                else:
                    in_origin_block = True
                    continue

            if in_origin_block:
                if line_upper.startswith("..XY") or line_upper.startswith(".XY") or line_upper.startswith("..PT") or line_upper.startswith(".PT"):
                    coords = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line_clean)
                    if len(coords) >= 2:
                        origin_x, origin_y = float(coords[0]), float(coords[1])
                        origin_found = True
                        break
                elif line_clean.startswith(".") or line_clean.startswith("!"):
                    in_origin_block = False
                else:
                    # Check bare coordinate pair
                    coords = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line_clean)
                    if len(coords) >= 2:
                        origin_x, origin_y = float(coords[0]), float(coords[1])
                        origin_found = True
                        break

        info.board_origin_x = origin_x
        info.board_origin_y = origin_y

        # 4. Parse Layer Count & Stackup (!.NUMBER_OF_LAYERS, LAYER_NAME_MAP, .LAYER_STACKUP)
        self.log("INFO", "Reading layer stack...")
        declared_layer_count = None
        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            m_num = re.search(r"[!\.]*NUMBER_OF_LAYERS\s+(\d+)", line_upper)
            if m_num:
                declared_layer_count = int(m_num.group(1))
                break

        all_layers: List[LayerInfo] = []
        in_stackup_block = False
        in_layer_map_block = False
        layer_index = 1

        for line in lines:
            line_strip = line.strip()
            line_upper = line_strip.upper()

            # Detect stackup or layer map sections
            if any(k in line_upper for k in ["..LAYER_STACKUP", "..STACKUP", ".STACK", ".LAYER_MAP", "LAYER_NAME_MAP", 'LAYER_NAME_MAP"']):
                if "LAYER_NAME_MAP" in line_upper:
                    in_layer_map_block = True
                else:
                    in_stackup_block = True
                continue
            elif (in_stackup_block or in_layer_map_block) and line_upper.startswith("..") and not any(k in line_upper for k in ["..CONDUCTOR", "..LAYER", "..XY"]):
                in_stackup_block = False
                in_layer_map_block = False
            elif line_clean.startswith(".") and not any(line_upper.startswith(k) for k in [".LAYER", ".TEXT", ".MAP"]):
                if in_layer_map_block and not line_upper.startswith(".TEXT"):
                    in_layer_map_block = False

            # Case A: Layer map lines like '"TOP" 1 CONDUCTOR SIGNAL' or '"GND1" 2' or '1 "TOP"'
            if in_layer_map_block:
                m_map = re.search(r'["\']([^"\']+)["\']\s+(\d+)(?:\s+(.*))?', line_strip)
                if m_map:
                    name_cand = m_map.group(1).strip()
                    idx_cand = int(m_map.group(2))
                    type_cand = (m_map.group(3) or "").strip()
                    layer_info = LayerDetector.classify_from_tokens(
                        name=name_cand,
                        index=idx_cand,
                        type_token=type_cand
                    )
                    all_layers.append(layer_info)
                    continue

                m_map_rev = re.search(r'(\d+)\s+["\']([^"\']+)["\'](?:\s+(.*))?', line_strip)
                if m_map_rev:
                    idx_cand = int(m_map_rev.group(1))
                    name_cand = m_map_rev.group(2).strip()
                    type_cand = (m_map_rev.group(3) or "").strip()
                    layer_info = LayerDetector.classify_from_tokens(
                        name=name_cand,
                        index=idx_cand,
                        type_token=type_cand
                    )
                    all_layers.append(layer_info)
                    continue

            # Case B: .LAYER directives (.LAYER "TOP" CONDUCTOR SIGNAL or .LAYER 1 "TOP")
            if in_stackup_block or line_upper.startswith(".LAYER") or line_upper.startswith("..CONDUCTOR_LAYER") or line_upper.startswith(".CONDUCTOR"):
                m_quoted = re.search(r'\.LAYER\s+(?:\d+\s+)?["\']([^"\']+)["\'](?:\s+(.*))?', line_strip, re.IGNORECASE)
                if m_quoted:
                    name_candidate = m_quoted.group(1).strip()
                    type_candidate = (m_quoted.group(2) or "").strip()
                    layer_info = LayerDetector.classify_from_tokens(
                        name=name_candidate,
                        index=layer_index,
                        type_token=type_candidate
                    )
                    all_layers.append(layer_info)
                    layer_index += 1
                else:
                    parts = line_strip.split()
                    if len(parts) >= 2:
                        name_candidate = parts[1].strip('"\'')
                        type_candidate = " ".join(parts[2:]) if len(parts) > 2 else ""
                        if not name_candidate.startswith(".."):
                            layer_info = LayerDetector.classify_from_tokens(
                                name=name_candidate,
                                index=layer_index,
                                type_candidate=type_candidate
                            ) if hasattr(LayerDetector, "type_candidate") else LayerDetector.classify_from_tokens(
                                name=name_candidate,
                                index=layer_index,
                                type_token=type_candidate
                            )
                            all_layers.append(layer_info)
                            layer_index += 1

        # Fallback to simple indexed layer lines if no stackup parsed
        if not all_layers:
            for line in lines:
                m = re.search(r"^\s*(\d+)\s*[\.:]?\s*([A-Za-z0-9_\-\s]+)", line)
                if m and not line.strip().upper().startswith(".."):
                    idx = int(m.group(1))
                    name = m.group(2).strip()
                    layer_info = LayerDetector.classify_from_tokens(name=name, index=idx)
                    all_layers.append(layer_info)

        # If no explicit layer definitions but declared layer count exists (!.NUMBER_OF_LAYERS)
        if not all_layers and declared_layer_count and declared_layer_count > 0:
            for i in range(1, declared_layer_count + 1):
                name = f"Layer {i}"
                if i == 1:
                    name = "Top (Layer 1)"
                elif i == declared_layer_count:
                    name = f"Bottom (Layer {i})"
                all_layers.append(
                    LayerInfo(
                        index=i,
                        name=name,
                        layer_class=LayerClass.CONDUCTOR,
                        conductor_subtype=ConductorSubtype.SIGNAL,
                        is_copper=True,
                        original_type_str="CONDUCTOR"
                    )
                )

        info.all_layers = all_layers
        copper_layers = LayerDetector.filter_copper_layers(all_layers)
        info.total_copper_layers = len(copper_layers)
        info.copper_layer_names = [l.name for l in copper_layers]
        
        # If total copper layers is 0 but declared_layer_count was given, respect the declared count
        if info.total_copper_layers == 0 and declared_layer_count:
            info.total_copper_layers = declared_layer_count
            if not info.copper_layer_names:
                info.copper_layer_names = [l.name for l in all_layers if l.is_copper]

        self.log("INFO", f"Copper layers detected: {info.total_copper_layers}")

        # 5. Parse Board Outline Geometry (.BOARD_OUTLINE, ..POLYARC_PATH, ...XYR (x, y, r), .PT)
        self.log("INFO", "Reading board outline...")
        points: List[Point] = []
        in_outline_block = False

        for line in lines:
            line_strip = line.strip()
            line_upper = line_strip.upper()

            if any(k in line_upper for k in ["..BOARD_OUTLINE", ".BOARD_OUTLINE", "..ROUTE_BORDER", ".ROUTE_BORDER",
                                             "..BOARD_BORDER", ".BOARD_BORDER", "..OUTLINE", ".OUTLINE", ".BORDER"]):
                in_outline_block = True
                continue
            elif in_outline_block and line_upper.startswith("..") and not any(k in line_upper for k in ["..PT", "..POLY", "..ARC", "..LINE", "..XY", "...XY"]):
                in_outline_block = False
            elif in_outline_block and line_clean.startswith(".") and not any(line_upper.startswith(k) for k in [".PT", ".XY", ".POLY", ".ARC"]):
                if not any(k in line_upper for k in ["POLYARC", "XYR", "PATH"]):
                    in_outline_block = False

            if in_outline_block:
                # Discard non-vertex directives inside outline block
                if any(line_upper.startswith(k) for k in [".LAYER", ".WIDTH", ".LINE_WIDTH", ".FILLET", ".TYPE", ".NET", ".CLEARANCE"]):
                    continue

                # Format 1: Parenthesized coordinates: ...XYR (x, y, r) or ...XYR (x, y) or (x, y, r) or (x, y)
                m_tuple = re.search(
                    r"\(\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)\s*,\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)(?:\s*,\s*[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)?\s*\)",
                    line_strip
                )
                if m_tuple:
                    try:
                        points.append(Point(x=float(m_tuple.group(1)), y=float(m_tuple.group(2))))
                        continue
                    except ValueError:
                        pass

                # Format 2: Directives: .PT, ..PT, .XY, ..XY, ...XYR x y r
                if any(line_upper.startswith(k) for k in [".PT", "..PT", ".XY", "..XY", "...XYR", "..XYR", ".POINT"]):
                    coords = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line_strip)
                    if len(coords) >= 2:
                        try:
                            points.append(Point(x=float(coords[0]), y=float(coords[1])))
                            continue
                        except ValueError:
                            pass

                # Format 3: Bare coordinate pair on line
                coords = re.findall(r"^[-+]?\d*\.?\d+\s*[, \t]\s*[-+]?\d*\.?\d+$", line_strip)
                if coords:
                    nums = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line_strip)
                    if len(nums) >= 2:
                        try:
                            points.append(Point(x=float(nums[0]), y=float(nums[1])))
                        except ValueError:
                            pass

        # Fallback vertex scan if outline block wasn't explicitly delimited
        if not points:
            for line in lines:
                line_clean = line.strip()
                line_u = line_clean.upper()
                m_tuple = re.search(
                    r"\(\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)\s*,\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)(?:\s*,\s*[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)?\s*\)",
                    line_clean
                )
                if m_tuple:
                    points.append(Point(x=float(m_tuple.group(1)), y=float(m_tuple.group(2))))
                elif line_u.startswith(".PT") or line_u.startswith("..PT") or line_u.startswith(".XY") or line_u.startswith("...XYR"):
                    coords = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line_clean)
                    if len(coords) >= 2:
                        points.append(Point(x=float(coords[0]), y=float(coords[1])))

        info.outline_points = points

        if points and OutlineDetector.validate_outline(points):
            info.board_outline_detected = True
            self.log("INFO", f"Board outline detected ({len(points)} vertices)")
            self.log("INFO", "Calculating bounding box...")
            bbox = OutlineDetector.calculate_bounding_box(points)
            if bbox:
                info.board_min_x = bbox.min_x
                info.board_max_x = bbox.max_x
                info.board_min_y = bbox.min_y
                info.board_max_y = bbox.max_y
                width, height, orientation = OutlineDetector.calculate_dimensions(bbox)
                info.board_width = width
                info.board_height = height
                info.orientation = orientation
                self.log("INFO", f"Board width: {width:.2f} {info.native_unit}")
                self.log("INFO", f"Board height: {height:.2f} {info.native_unit}")
                self.log("INFO", f"Orientation: {orientation}")
        else:
            info.board_outline_detected = False
            self.log("WARNING", "Board outline not detected.")
            info.calculate_dimensions()

        # If nothing could be recognized at all, fail validation
        if not all_layers and not points:
            return False

        return True

    def _inspect_binary_stream(self, abs_path: str, info: PCBInfo) -> PCBInfo:
        """
        Intelligently inspects a binary .pcb / .lyt stream.
        Safely extracts embedded ASCII/UTF-8 strings (design name, layer names,
        stackup count, Xpedition version) and provides actionable diagnostic instructions.
        """
        info.reader_backend = "Xpedition Binary Stream Inspector (Read-Only)"
        self.log("INFO", "Binary PCB database detected. Performing intelligent stream inspection...")

        try:
            # Safely read binary stream (up to 10MB)
            with open(abs_path, "rb") as bf:
                raw_bytes = bf.read(10 * 1024 * 1024)

            # Extract printable ASCII sequences (>= 3 chars)
            ascii_strings = [
                s.decode("ascii", errors="ignore").strip()
                for s in re.findall(rb"[\x20-\x7E]{3,}", raw_bytes)
            ]

            # Extract UTF-16LE sequences
            utf16_strings = []
            for raw_u in re.findall(rb"(?:[\x20-\x7E]\x00){3,}", raw_bytes):
                try:
                    utf16_strings.append(raw_u.decode("utf-16le", errors="ignore").strip())
                except Exception:
                    pass

            all_extracted_strings = ascii_strings + utf16_strings

            # 1. Search for Xpedition / Mentor version indicators
            version_detected = "Xpedition Layout Database"
            for s in all_extracted_strings:
                v_match = re.search(
                    r"(?:Expedition|Xpedition|Mentor\s+Graphics|Siemens\s+EDA|EE\s*\d+\.\d+|VX\.\d+|2510(?:\.\d+)?)",
                    s,
                    re.IGNORECASE
                )
                if v_match:
                    version_detected = s
                    break

            # 2. Search for Design Name
            for s in all_extracted_strings:
                if any(s.upper().startswith(k) for k in ["DESIGN:", "DESIGN_NAME", "JOB:", "PCB_NAME"]):
                    parts = s.split(":", 1)
                    if len(parts) > 1 and parts[1].strip():
                        info.pcb_name = parts[1].strip()
                        break

            # 3. Identify Layer Names from binary string table
            identified_layers: List[LayerInfo] = []
            seen_names = set()
            layer_idx = 1

            for s in all_extracted_strings:
                s_clean = s.strip().strip('"\'')
                # Check if this string matches copper layer patterns
                if 2 <= len(s_clean) <= 32:
                    is_cop, lc, st = LayerDetector.classify_by_name(s_clean)
                    if is_cop and s_clean.upper() not in seen_names:
                        seen_names.add(s_clean.upper())
                        identified_layers.append(
                            LayerInfo(
                                index=layer_idx,
                                name=s_clean,
                                layer_class=lc,
                                conductor_subtype=st,
                                is_copper=True,
                                original_type_str="Extracted from binary stream"
                            )
                        )
                        layer_idx += 1

            # Check for stackup count in strings
            for s in all_extracted_strings:
                cnt_match = re.search(r"NUMBER_OF_LAYERS\s*[:=]?\s*(\d+)", s, re.IGNORECASE)
                if cnt_match:
                    cnt = int(cnt_match.group(1))
                    if cnt > len(identified_layers):
                        for i in range(len(identified_layers) + 1, cnt + 1):
                            name = f"Layer_{i}"
                            identified_layers.append(
                                LayerInfo(
                                    index=i,
                                    name=name,
                                    layer_class=LayerClass.CONDUCTOR,
                                    conductor_subtype=ConductorSubtype.SIGNAL,
                                    is_copper=True,
                                    original_type_str="Binary stackup count"
                                )
                            )
                    break

            info.all_layers = identified_layers
            copper = LayerDetector.filter_copper_layers(identified_layers)
            info.total_copper_layers = len(copper)
            info.copper_layer_names = [l.name for l in copper]
            info.board_outline_detected = False
            info.calculate_dimensions()

            # Generate diagnostic guidance
            layer_summary = ", ".join(info.copper_layer_names) if info.copper_layer_names else "No layers found"
            diag_guidance = (
                f"Binary Xpedition .pcb file inspected. Extracted metadata: Design '{info.pcb_name}', "
                f"Version '{version_detected}', {info.total_copper_layers} copper layers ({layer_summary}). "
                "For full vector geometry & outline bounding box on systems without Xpedition COM Automation, "
                "export HKP ASCII (File -> Export -> Keyin Netlist/HKP) or Gerber Board Outline (.GKO / .GM1 / .GBO)."
            )

            if info.total_copper_layers > 0 or version_detected != "Xpedition Layout Database":
                self.log("INFO", diag_guidance)
                info.extraction_successful = True
                info.error_message = diag_guidance
            else:
                self.log("ERROR", "Binary PCB file does not contain recognizable Xpedition database structures.")
                info.extraction_successful = False
                info.error_message = (
                    "PCB format or Xpedition API interface could not be accessed. "
                    "(Xpedition Layout COM Automation is required to read binary .pcb files or export to HKP/Gerber format)"
                )

            return info

        except Exception as ex:
            self.log("ERROR", f"Failed inspecting binary stream: {str(ex)}")
            info.extraction_successful = False
            info.error_message = (
                f"PCB format or Xpedition API interface could not be accessed: {str(ex)}. "
                "(Xpedition Layout COM Automation is required to read binary .pcb files)"
            )
            return info
