"""
PCB Information Extractor Orchestrator.

Coordinates reader engines (COM Automation -> Direct File Reader -> Mock Simulation),
validates extracted data, logs progress steps, and enforces 100% read-only protection.
"""

import os
from typing import Optional, List
from .interface import IPCBReader, LogCallback
from .models import PCBInfo
from .com_reader import XpeditionCOMReader
from .direct_reader import XpeditionDirectFileReader
from .mock_reader import MockXpeditionReader


class PCBInformationExtractor:
    """
    Main extraction coordinator for Siemens Xpedition Layout PCB designs.
    """

    def __init__(self, log_cb: Optional[LogCallback] = None, force_backend: Optional[str] = None):
        """
        :param log_cb: Callback function for live log stream (level, message).
        :param force_backend: Optional override: 'com', 'direct', or 'mock'.
        """
        self.log_cb = log_cb
        self.force_backend = force_backend
        
        # Instantiate readers with logger
        self.com_reader = XpeditionCOMReader(log_cb=self._log)
        self.direct_reader = XpeditionDirectFileReader(log_cb=self._log)
        self.mock_reader = MockXpeditionReader(log_cb=self._log)

    def _log(self, level: str, message: str) -> None:
        if self.log_cb:
            self.log_cb(level, message)

    def get_available_backends(self) -> List[str]:
        """Returns list of available extraction backend names."""
        backends = []
        if self.com_reader.is_available():
            backends.append("Siemens Xpedition 2510 COM Automation (Live)")
        else:
            backends.append("Siemens Xpedition COM (Offline / Not Registered)")
        backends.append("Direct File Parser (HKP / Gerber / Offline)")
        backends.append("Xpedition Test Simulation Engine")
        return backends

    def extract(self, file_path: str) -> PCBInfo:
        """
        Extract complete PCB information from the specified file.
        
        Selection hierarchy:
        1. If force_backend is 'com', use COM reader.
        2. If force_backend is 'direct', use Direct File reader.
        3. If force_backend is 'mock', use Mock reader.
        4. Auto mode:
           - If mock prefix or simulation is requested, use Mock reader.
           - If COM reader is available on the machine, use COM reader.
           - Fallback to Direct File reader for HKP, Gerber, and binary files.
           - If extraction fails, report the actual error (never fabricate fake data).
        """
        if not file_path or not file_path.strip():
            self._log("ERROR", "No PCB file specified.")
            info = PCBInfo(
                pcb_name="",
                file_path="",
                extraction_successful=False,
                error_message="Unable to read PCB file: No file path provided."
            )
            return info

        clean_path = file_path.strip().strip('"').strip("'")
        self._log("INFO", f"Selected PCB: {clean_path}")

        # Forced backend mode
        if self.force_backend == "com":
            self._log("INFO", "Using forced COM Automation engine...")
            return self._validate_and_finalize(self.com_reader.read_pcb(clean_path))
        elif self.force_backend == "direct":
            self._log("INFO", "Using forced Direct File parser engine...")
            return self._validate_and_finalize(self.direct_reader.read_pcb(clean_path))
        elif self.force_backend == "mock":
            self._log("INFO", "Using simulation benchmark engine...")
            return self._validate_and_finalize(self.mock_reader.read_pcb(clean_path))

        # Synthetic mock prefix check
        if clean_path.startswith("mock:") or clean_path.startswith("sim:"):
            self._log("INFO", "Using test simulation engine for synthetic design...")
            return self._validate_and_finalize(self.mock_reader.read_pcb(clean_path))

        # Check if file exists on disk
        if not os.path.exists(clean_path):
            self._log("ERROR", f"PCB file not found: {clean_path}")
            info = PCBInfo(
                pcb_name=os.path.splitext(os.path.basename(clean_path))[0],
                file_path=os.path.abspath(clean_path),
                extraction_successful=False,
                error_message=f"Unable to read PCB file: File does not exist ({clean_path})."
            )
            return self._validate_and_finalize(info)

        # Auto-selection logic: Try COM if available
        if self.com_reader.is_available():
            self._log("INFO", f"Siemens Xpedition COM interface detected ({self.com_reader.get_status_description()}). Initializing COM reader...")
            info = self.com_reader.read_pcb(clean_path)
            if info.extraction_successful:
                return self._validate_and_finalize(info)
            else:
                self._log("WARNING", f"COM extraction unsuccessful ({info.error_message}). Attempting direct file parser...")
        else:
            self._log("INFO", "Siemens Xpedition COM interface offline/not registered on host. Routing to Direct File Parser...")

        # Direct file parser (HKP / Gerber / Binary inspection)
        self._log("INFO", "Reading design via direct Xpedition parser...")
        info = self.direct_reader.read_pcb(clean_path)
        return self._validate_and_finalize(info)

    def _validate_and_finalize(self, info: PCBInfo) -> PCBInfo:
        """Post-extraction validation against domain rules."""
        # 1. Copper Layer Validation
        if info.total_copper_layers == 0 and info.reader_backend != "RS-274X Gerber Outline Parser (Read-Only)":
            self._log("WARNING", "Copper layer count could not be determined.")
        else:
            self._log("INFO", f"Validated copper layer count: {info.total_copper_layers}")

        # 2. Board Outline Validation
        if not info.board_outline_detected:
            self._log("WARNING", "Board outline not detected.")
        else:
            self._log("INFO", f"Validated board outline: {info.board_width:.2f} x {info.board_height:.2f} {info.native_unit} ({info.orientation})")

        # 3. Always enforce read-only protection flag
        info.is_read_only = True
        return info
